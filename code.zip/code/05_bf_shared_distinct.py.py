# -*- coding: utf-8 -*-
"""
bf_shared_distinct_analysis_and_figure.py
=========================================

Bayes-factor classification of common and dimension-specific neural correlates
for Goal congruence and Responsibility attribution.

INPUT
-----
Existing first-level beta matrices:
    beta_layer1_goal_resp_goal.csv
    beta_layer1_goal_resp_responsibility.csv

Expected structure:
    rows    = participants (normally N = 40)
    columns = 221 ROIs
              first 200 = Schaefer-200 cortical parcels
              last 21  = Harvard-Oxford entries

NO first-level GLM is rerun.

MAIN ANALYSIS
-------------
For each ROI and each appraisal dimension:
1. Compute a group one-sample t statistic against zero using scipy.stats.ttest_1samp.
2. Convert t and N to a JZS Bayes factor BF10 using scale:
       r = sqrt(2) / 2
3. Evidence thresholds:
       BF10 > 5      -> evidence for an effect
       BF10 < 1/5    -> evidence for the null
       otherwise     -> uncertain
4. Classify each ROI:
       Both
       Goal-specific
       Responsibility-specific
       Uncertain

Because Goal and Responsibility are genuinely signed bipolar variables,
the present analysis is TWO-SIDED. "Both" is further divided descriptively:
       Both-same-sign
       Both-opposite-sign

This differs intentionally from Miao et al. (2026), whose BF classification
retained only positive effects.

FIGURE
------
One combined publication-style figure inspired by Miao et al. Fig. 6:

a. Surface projection of cortical BF classes
   - Goal-specific
   - Responsibility-specific
   - Both, same sign
   - Both, opposite sign
   - Uncertain is shown only as anatomical background

b. Group-level log10(BF10) for four selected representative ROIs
   - Goal: circle
   - Responsibility: square
   - dashed lines at BF10 = 5 and BF10 = 1/5
   You may manually set SELECTED_ROIS below.
   If SELECTED_ROIS is empty, four illustrative ROIs are selected
   automatically from the classification results.

c. Venn-style summary of the 215 neural ROIs
   - Goal-specific
   - Responsibility-specific
   - Both
   - Uncertain is reported below the circles

OUTPUTS
-------
BF_shared_distinct_pingouin_scipy/
    bf_classification_all221.csv
    bf_classification_neural215.csv
    bf_classification_cortical200.csv
    bf_class_counts_neural215.csv
    bf_selected_rois.csv
    bf_class_cortical200.nii.gz

    Fig_BF_shared_distinct.svg
    Fig_BF_shared_distinct.pdf
    Fig_BF_shared_distinct.png

Dependencies
------------
python -m pip install numpy pandas scipy matplotlib nibabel nilearn pingouin
"""

from pathlib import Path
import math
import re
import warnings

import numpy as np
import pandas as pd
import pingouin as pg
from scipy import stats

import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from matplotlib.patches import Circle

import nibabel as nib
from nilearn import datasets, image, plotting, surface


# =====================================================================
# 1. PATHS
# =====================================================================

# Change this only if your beta CSV files are elsewhere.
RESULT_DIR = Path(r"C:\Users\tsuki\glm_layer1_goal_resp")

GOAL_BETA_FILE = RESULT_DIR / "beta_layer1_goal_resp_goal.csv"
RESP_BETA_FILE = RESULT_DIR / "beta_layer1_goal_resp_responsibility.csv"

OUT_DIR = RESULT_DIR / "BF_shared_distinct_pingouin_scipy"
OUT_DIR.mkdir(parents=True, exist_ok=True)


# =====================================================================
# 2. BF PARAMETERS
# =====================================================================

# Same JZS scale used in the reference analysis.
JZS_R = np.sqrt(2.0) / 2.0

BF_EFFECT = 5.0
BF_NULL = 1.0 / 5.0

N_SCHAEFER = 200
N_EXPECTED_ALL = 221
N_EXPECTED_NEURAL = 215

# Surface template. fsaverage5 is fast and adequate for Schaefer-200.
SURFACE_MESH = "fsaverage5"

# Four manually chosen ROIs for panel b.
# IMPORTANT:
# - Prefer a priori / theoretically motivated ROIs for the final manuscript.
# - Leave empty [] to let the script choose four illustrative ROIs automatically.
#
# Example:
# SELECTED_ROIS = [
#     "7Networks_LH_Default_PFC_8",
#     "7Networks_RH_DorsAttn_Post_5",
#     "7Networks_LH_Vis_11",
#     "7Networks_RH_SomMot_2",
# ]
SELECTED_ROIS = [
    # Both-same-sign: shared posterior DMN node
    "7Networks_RH_Default_pCunPCC_1",
    # Goal-specific: Default-mode prefrontal parcel
    "7Networks_LH_Default_PFC_8",
    # Responsibility-specific: posterior dorsal-attention parcel
    "7Networks_RH_DorsAttn_Post_6",
    # Both-opposite-sign: sensorimotor parcel
    "7Networks_RH_SomMot_1",
]

# Short display names used only in Panel b.
PANEL_B_LABELS = {
    "7Networks_RH_Default_pCunPCC_1": "R pCun/PCC",
    "7Networks_LH_Default_PFC_8": "L Default PFC",
    "7Networks_RH_DorsAttn_Post_6": "R DAN Post",
    "7Networks_RH_SomMot_1": "R SomMot",
}


# =====================================================================
# 3. COLORS / FIGURE STYLE
# =====================================================================

GOAL_COLOR = "#2D6A4F"          # green
RESP_COLOR = "#7B4F9D"          # purple
BOTH_SAME_COLOR = "#3D6FA3"     # blue
BOTH_OPP_COLOR = "#D9822B"      # orange
UNCERTAIN_COLOR = "#D9D9D9"
DARK_GRAY = "#4D4D4D"
LIGHT_GRAY = "#ECECEC"

mpl.rcParams["svg.fonttype"] = "none"
mpl.rcParams["pdf.fonttype"] = 42
mpl.rcParams["ps.fonttype"] = 42
mpl.rcParams["font.family"] = "Arial"
mpl.rcParams["font.size"] = 10
mpl.rcParams["axes.titlesize"] = 12
mpl.rcParams["axes.labelsize"] = 11
mpl.rcParams["xtick.labelsize"] = 10
mpl.rcParams["ytick.labelsize"] = 10
mpl.rcParams["axes.linewidth"] = 0.7
mpl.rcParams["xtick.major.width"] = 0.6
mpl.rcParams["ytick.major.width"] = 0.6


# =====================================================================
# 4. NON-NEURAL / REDUNDANT HARVARD-OXFORD ENTRIES
# =====================================================================

# Exact spelling is matched after .strip().
# "Ventrical" is kept because it appeared in an earlier CSV header;
# "Ventricle" is the alternate spelling.
NON_NEURAL_HO = {
    "Left Cerebral White Matter",
    "Left Cerebral Cortex",
    "Left Lateral Ventrical",
    "Left Lateral Ventricle",
    "Right Cerebral White Matter",
    "Right Cerebral Cortex",
    "Right Lateral Ventricle",
}


# =====================================================================
# 5. BASIC HELPERS
# =====================================================================

def read_beta_matrix(path: Path) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(
            f"Cannot find:\n{path}\n\n"
            "Please edit RESULT_DIR at the top of this script."
        )

    df = pd.read_csv(path, index_col=0)
    df = df.apply(pd.to_numeric, errors="coerce")
    df = df.dropna(axis=1, how="all")

    if df.isna().any().any():
        bad = np.argwhere(df.isna().to_numpy())
        i, j = bad[0]
        raise ValueError(
            f"{path.name} contains NaN/non-numeric data at "
            f"subject={df.index[i]}, ROI={df.columns[j]}."
        )

    return df


def normalize_roi_name(name):
    return str(name).strip()


def is_schaefer(roi):
    return normalize_roi_name(roi).startswith("7Networks_")


def is_non_neural_ho(roi):
    return normalize_roi_name(roi) in NON_NEURAL_HO


def get_roi_sets(columns):
    cols = [normalize_roi_name(c) for c in columns]

    cortical = [c for c in cols if is_schaefer(c)]
    neural = [
        c for c in cols
        if is_schaefer(c) or (not is_non_neural_ho(c))
    ]

    if len(cortical) != N_SCHAEFER:
        warnings.warn(
            f"Expected {N_SCHAEFER} Schaefer cortical ROIs, "
            f"found {len(cortical)}."
        )

    if len(neural) != N_EXPECTED_NEURAL:
        warnings.warn(
            f"Expected {N_EXPECTED_NEURAL} neural ROIs after exclusions, "
            f"found {len(neural)}."
        )

    return cortical, neural


def one_sample_stats(x):
    """Descriptive statistics plus SciPy's established one-sample t-test.

    Parameters
    ----------
    x : array-like, shape (participants, ROIs)
        Participant-level beta values. Missing values are not silently omitted;
        the function raises an error so that N remains consistent with the BF test.

    Returns
    -------
    means, sds, tvals, pvals, dz : ndarray
        Per-ROI mean, sample SD, t statistic, two-sided p value, and Cohen's dz.
    """
    x = np.asarray(x, dtype=float)
    if x.ndim != 2:
        raise ValueError(f"Expected a participants-by-ROIs matrix; got shape {x.shape}.")
    if not np.isfinite(x).all():
        raise ValueError("Beta matrix contains NaN or infinite values; resolve these before analysis.")

    n = x.shape[0]
    means = np.mean(x, axis=0)
    sds = np.std(x, axis=0, ddof=1)

    # Mature, library-provided inferential test; two-sided one-sample t-test against zero.
    test = stats.ttest_1samp(x, popmean=0.0, axis=0, alternative="two-sided", nan_policy="raise")
    tvals = np.asarray(test.statistic, dtype=float)
    pvals = np.asarray(test.pvalue, dtype=float)

    # Cohen's dz for a one-sample test against zero: mean / sample SD.
    with np.errstate(divide="ignore", invalid="ignore"):
        dz = means / sds

    return means, sds, tvals, pvals, dz


# =====================================================================
# 6. JZS BAYES FACTOR VIA PINGOUIN
# =====================================================================
# BF10 is calculated directly with Pingouin's built-in bayesfactor_ttest.
# No custom Bayes-factor integration function is used.


def evidence_state(bf):
    if not np.isfinite(bf):
        return "missing"
    if bf > BF_EFFECT:
        return "effect"
    if bf < BF_NULL:
        return "null"
    return "uncertain"


def classify_roi(goal_bf, resp_bf, goal_t, resp_t):
    """
    Main classification.
    """
    g = evidence_state(goal_bf)
    r = evidence_state(resp_bf)

    if g == "effect" and r == "effect":
        if np.sign(goal_t) == np.sign(resp_t):
            return "Both-same-sign"
        return "Both-opposite-sign"

    if g == "effect" and r == "null":
        return "Goal-specific"

    if g == "null" and r == "effect":
        return "Responsibility-specific"

    return "Uncertain"


def broad_class(fine_class):
    if fine_class in {"Both-same-sign", "Both-opposite-sign"}:
        return "Both"
    return fine_class


# =====================================================================
# 7. SCHAEFER ATLAS HELPERS
# =====================================================================

def decode_labels(labels):
    out = []
    for x in labels:
        if isinstance(x, bytes):
            out.append(x.decode("utf-8"))
        else:
            out.append(str(x))
    return out


def normalize_label(x):
    s = str(x).lower()
    s = s.replace("schaefer", "")
    s = s.replace("roi", "")
    s = re.sub(r"[^a-z0-9]", "", s)
    return s


def verify_schaefer_order(beta_columns, atlas_labels):
    beta_first = list(beta_columns[:N_SCHAEFER])

    if len(atlas_labels) != N_SCHAEFER:
        raise ValueError(
            f"Atlas has {len(atlas_labels)} parcel labels after background removal; "
            f"expected {N_SCHAEFER}."
        )

    ok = []
    for b, a in zip(beta_first, atlas_labels):
        nb = normalize_label(b)
        na = normalize_label(a)
        ok.append((nb == na) or (nb in na) or (na in nb))

    rate = float(np.mean(ok))
    print(f"Schaefer label-order match rate: {rate:.3f}")

    if rate < 0.80:
        examples = []
        for i, flag in enumerate(ok):
            if not flag:
                examples.append(
                    f"#{i+1}: beta='{beta_first[i]}' | atlas='{atlas_labels[i]}'"
                )
            if len(examples) >= 5:
                break

        raise ValueError(
            "The first 200 beta columns do not appear to match the "
            "standard Schaefer-200 atlas order.\n"
            "Examples:\n  " + "\n  ".join(examples)
        )


def parcel_values_to_nifti(parcel_values, atlas_img):
    atlas_data = atlas_img.get_fdata().astype(np.int32)
    out = np.zeros(atlas_data.shape, dtype=np.float32)

    for parcel_index, value in enumerate(parcel_values, start=1):
        out[atlas_data == parcel_index] = float(value)

    return image.new_img_like(atlas_img, out)


def project_discrete_to_surface(stat_img, fsavg, hemi):
    """
    Nearest-neighbor projection for categorical BF classes.

    Compatibility:
    - tries interpolation='nearest'
    - falls back to default projection + rounding if needed
    """
    if hemi == "left":
        pial = fsavg.pial_left
        white = fsavg.white_left
    else:
        pial = fsavg.pial_right
        white = fsavg.white_right

    try:
        tex = surface.vol_to_surf(
            stat_img,
            pial,
            inner_mesh=white,
            interpolation="nearest",
        )
    except (TypeError, ValueError):
        warnings.warn(
            "Your Nilearn version did not accept interpolation='nearest'. "
            "Falling back to default projection and rounding class values."
        )
        tex = surface.vol_to_surf(
            stat_img,
            pial,
            inner_mesh=white,
        )

    # Restore discrete class codes after projection.
    tex = np.rint(tex)
    tex = np.clip(tex, 0, 4)

    return tex


# =====================================================================
# 8. PANEL-B ROI SELECTION
# =====================================================================

def classification_confidence(row):
    """
    Descriptive score only, used to choose illustrative ROIs when
    SELECTED_ROIS is left empty.
    """
    g = row["goal_log10_bf10"]
    r = row["responsibility_log10_bf10"]
    cls = row["bf_class"]

    if cls in {"Both-same-sign", "Both-opposite-sign"}:
        return min(g, r)
    if cls == "Goal-specific":
        return g - r
    if cls == "Responsibility-specific":
        return r - g
    return max(g, r)


def auto_select_rois(df_neural, n_select=4):
    """
    Tries to represent multiple BF classes rather than simply taking the
    four largest BFs.
    """
    preferred_classes = [
        "Both-same-sign",
        "Goal-specific",
        "Responsibility-specific",
        "Both-opposite-sign",
    ]

    chosen = []

    for cls in preferred_classes:
        sub = df_neural[df_neural["bf_class"] == cls].copy()
        if len(sub) == 0:
            continue

        sub["__score__"] = sub.apply(classification_confidence, axis=1)
        roi = sub.sort_values("__score__", ascending=False).iloc[0]["roi"]

        if roi not in chosen:
            chosen.append(roi)

        if len(chosen) >= n_select:
            break

    if len(chosen) < n_select:
        remaining = df_neural[
            (df_neural["bf_class"] != "Uncertain")
            & (~df_neural["roi"].isin(chosen))
        ].copy()

        if len(remaining):
            remaining["__score__"] = remaining.apply(
                classification_confidence, axis=1
            )
            for roi in remaining.sort_values(
                "__score__", ascending=False
            )["roi"]:
                if roi not in chosen:
                    chosen.append(roi)
                if len(chosen) >= n_select:
                    break

    # If there still are fewer than 4 classified ROIs, fill from uncertain
    # by strongest max BF, solely for displaying panel b.
    if len(chosen) < n_select:
        remaining = df_neural[~df_neural["roi"].isin(chosen)].copy()
        remaining["__score__"] = remaining[
            ["goal_log10_bf10", "responsibility_log10_bf10"]
        ].max(axis=1)

        for roi in remaining.sort_values(
            "__score__", ascending=False
        )["roi"]:
            chosen.append(roi)
            if len(chosen) >= n_select:
                break

    return chosen[:n_select]


def short_roi_label(roi):
    s = str(roi)
    if s.startswith("7Networks_"):
        return s.replace("7Networks_", "")
    replacements = {
        "Left ": "L ",
        "Right ": "R ",
    }
    for old, new in replacements.items():
        if s.startswith(old):
            s = s.replace(old, new, 1)
    return s


# =====================================================================
# 9. FIGURE HELPERS
# =====================================================================

def clean_axis(ax):
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)


def add_panel_letter(fig, x, y, letter, title):
    fig.text(
        x, y,
        f"{letter}. {title}",
        ha="left",
        va="top",
        fontsize=15,
        fontweight="bold",
    )


def draw_surface_panel(fig, gs_cell, class_img):
    """
    Panel a: four cortical surface views.
    """
    fsavg = datasets.fetch_surf_fsaverage(mesh=SURFACE_MESH)

    tex_l = project_discrete_to_surface(class_img, fsavg, "left")
    tex_r = project_discrete_to_surface(class_img, fsavg, "right")

    # Keep only classified codes 1..4; 0 = uncertain/background.
    cmap = ListedColormap([
        GOAL_COLOR,
        RESP_COLOR,
        BOTH_SAME_COLOR,
        BOTH_OPP_COLOR,
    ])

    sub = gs_cell.subgridspec(
        1, 4,
        wspace=-0.08,
    )

    configs = [
        ("left", "lateral", fsavg.infl_left, fsavg.sulc_left, tex_l),
        ("left", "medial", fsavg.infl_left, fsavg.sulc_left, tex_l),
        ("right", "medial", fsavg.infl_right, fsavg.sulc_right, tex_r),
        ("right", "lateral", fsavg.infl_right, fsavg.sulc_right, tex_r),
    ]

    for i, (hemi, view, mesh, sulc, tex) in enumerate(configs):
        ax = fig.add_subplot(sub[0, i], projection="3d")

        plotting.plot_surf_stat_map(
            surf_mesh=mesh,
            stat_map=tex,
            bg_map=sulc,
            hemi=hemi,
            view=view,
            cmap=cmap,
            colorbar=False,
            threshold=0.5,
            vmin=1.0,
            vmax=4.0,
            bg_on_data=False,
            axes=ax,
            figure=fig,
        )

        ax.set_axis_off()

    # Manual legend for discrete classes.
    legend_ax = fig.add_axes([0.145, 0.515, 0.74, 0.042])
    legend_ax.axis("off")

    labels = [
        ("Goal-specific", GOAL_COLOR),
        ("Responsibility-specific", RESP_COLOR),
        ("Both, same sign", BOTH_SAME_COLOR),
        ("Both, opposite sign", BOTH_OPP_COLOR),
    ]

    x_positions = [0.03, 0.29, 0.61, 0.82]

    for (label, color), x in zip(labels, x_positions):
        legend_ax.scatter(
            [x], [0.5],
            s=42,
            marker="s",
            color=color,
            transform=legend_ax.transAxes,
            clip_on=False,
        )
        legend_ax.text(
            x + 0.025, 0.5,
            label,
            transform=legend_ax.transAxes,
            va="center",
            ha="left",
            fontsize=9,
        )


def draw_bf_panel(ax, selected_df):
    """
    Panel b: group-level log10 BF10 for selected ROIs.
    """
    x = np.arange(len(selected_df), dtype=float)

    goal_y = selected_df["goal_log10_bf10"].to_numpy(float)
    resp_y = selected_df["responsibility_log10_bf10"].to_numpy(float)

    # Slight horizontal jitter so both dimensions are visible.
    jitter = 0.10

    ax.scatter(
        x - jitter,
        goal_y,
        s=38,
        marker="o",
        color=GOAL_COLOR,
        edgecolor="white",
        linewidth=0.5,
        zorder=3,
        label="Goal congruence",
    )
    ax.scatter(
        x + jitter,
        resp_y,
        s=42,
        marker="s",
        color=RESP_COLOR,
        edgecolor="white",
        linewidth=0.5,
        zorder=3,
        label="Responsibility attribution",
    )

    upper = np.log10(BF_EFFECT)
    lower = np.log10(BF_NULL)

    ax.axhline(
        upper,
        color="black",
        linestyle="--",
        linewidth=0.9,
    )
    ax.axhline(
        lower,
        color="black",
        linestyle="--",
        linewidth=0.9,
    )
    ax.axhline(
        0,
        color="#999999",
        linestyle=":",
        linewidth=0.7,
    )

    ax.set_xticks(x)
    ax.set_xticklabels(
        [PANEL_B_LABELS.get(r, short_roi_label(r)) for r in selected_df["roi"]],
        rotation=18,
        ha="right",
        fontsize=9.5,
    )

    ax.set_ylabel(r"$\log_{10}(BF_{10})$")
    ax.set_xlabel("Selected ROIs")

    # Labels for evidence zones.
    y_min, y_max = ax.get_ylim()
    x_text = len(selected_df) - 0.35

    ax.text(
        x_text, upper + 0.07 * (y_max - y_min),
        "Alternative",
        fontsize=9,
        style="italic",
        ha="right",
        va="bottom",
    )
    ax.text(
        x_text, lower - 0.07 * (y_max - y_min),
        "Null",
        fontsize=9,
        style="italic",
        ha="right",
        va="top",
    )
    ax.text(
        x_text, 0,
        "Uncertain",
        fontsize=9,
        style="italic",
        ha="right",
        va="center",
    )

    ax.legend(
        frameon=False,
        loc="upper left",
        fontsize=9,
        handletextpad=0.4,
    )

    clean_axis(ax)


def draw_venn_panel(ax, counts):
    """
    Panel c: Venn-style ROI count summary without external dependencies.
    """
    ax.set_aspect("equal")
    ax.axis("off")

    n_total = counts["total"]
    n_goal = counts["Goal-specific"]
    n_resp = counts["Responsibility-specific"]
    n_both = counts["Both"]
    n_unc = counts["Uncertain"]

    left_center = (0.42, 0.55)
    right_center = (0.62, 0.55)
    radius = 0.25

    left_circle = Circle(
        left_center,
        radius,
        facecolor=GOAL_COLOR,
        alpha=0.25,
        edgecolor=GOAL_COLOR,
        linewidth=1.2,
    )
    right_circle = Circle(
        right_center,
        radius,
        facecolor=RESP_COLOR,
        alpha=0.25,
        edgecolor=RESP_COLOR,
        linewidth=1.2,
    )

    ax.add_patch(left_circle)
    ax.add_patch(right_circle)

    def pct(n):
        return 100.0 * n / n_total if n_total else np.nan

    ax.text(
        0.28, 0.56,
        f"{n_goal}\n({pct(n_goal):.1f}%)",
        ha="center",
        va="center",
        fontsize=11,
        fontweight="bold",
    )
    ax.text(
        0.76, 0.56,
        f"{n_resp}\n({pct(n_resp):.1f}%)",
        ha="center",
        va="center",
        fontsize=11,
        fontweight="bold",
    )
    ax.text(
        0.52, 0.57,
        f"{n_both}\n({pct(n_both):.1f}%)",
        ha="center",
        va="center",
        fontsize=11,
        fontweight="bold",
    )
    ax.text(
        0.23, 0.88,
        "Goal congruence",
        color=GOAL_COLOR,
        ha="center",
        va="center",
        fontsize=10,
        fontweight="bold",
    )
    ax.text(
        0.81, 0.88,
        "Responsibility attribution",
        color=RESP_COLOR,
        ha="center",
        va="center",
        fontsize=10,
        fontweight="bold",
    )

    ax.text(
        0.52, 0.12,
        f"Uncertain: {n_unc} ({pct(n_unc):.1f}%)\n"
        f"Total neural ROIs: {n_total}",
        ha="center",
        va="center",
        fontsize=9,
        color=DARK_GRAY,
    )

    ax.set_xlim(0.05, 0.99)
    ax.set_ylim(0.02, 0.98)


# =====================================================================
# 10. LOAD AND ALIGN DATA
# =====================================================================

print("=" * 74)
print("Loading beta matrices")
print("=" * 74)
print(f"Pingouin version: {pg.__version__}")

goal_df = read_beta_matrix(GOAL_BETA_FILE)
resp_df = read_beta_matrix(RESP_BETA_FILE)

common_subjects = goal_df.index.intersection(resp_df.index)
common_rois = goal_df.columns.intersection(resp_df.columns)

if len(common_subjects) != goal_df.shape[0] or len(common_subjects) != resp_df.shape[0]:
    warnings.warn("Subject IDs differ; using the overlapping subjects only.")

if len(common_rois) != goal_df.shape[1] or len(common_rois) != resp_df.shape[1]:
    warnings.warn("ROI columns differ; using the overlapping ROI columns only.")

# Preserve Goal file order.
common_rois_ordered = [c for c in goal_df.columns if c in common_rois]

goal_df = goal_df.loc[common_subjects, common_rois_ordered]
resp_df = resp_df.loc[common_subjects, common_rois_ordered]

n_subjects = len(common_subjects)

print(f"Participants: {n_subjects}")
print(f"ROI columns: {len(common_rois_ordered)}")

if len(common_rois_ordered) != N_EXPECTED_ALL:
    warnings.warn(
        f"Expected {N_EXPECTED_ALL} total ROI columns, "
        f"found {len(common_rois_ordered)}."
    )

cortical_rois, neural_rois = get_roi_sets(common_rois_ordered)

print(f"Schaefer cortical ROIs: {len(cortical_rois)}")
print(f"Primary neural ROIs: {len(neural_rois)}")


# =====================================================================
# 11. GROUP t STATISTICS
# =====================================================================

print("\n" + "=" * 74)
print("Computing group-level one-sample t statistics")
print("=" * 74)

goal_mean, goal_sd, goal_t, goal_p, goal_dz = one_sample_stats(
    goal_df.to_numpy(float)
)
resp_mean, resp_sd, resp_t, resp_p, resp_dz = one_sample_stats(
    resp_df.to_numpy(float)
)


# =====================================================================
# 12. BF10
# =====================================================================

print("\n" + "=" * 74)
print("Computing JZS BF10 for Goal")
print("=" * 74)
goal_bf = np.array([
    pg.bayesfactor_ttest(
        t=float(tval), nx=n_subjects, alternative="two-sided", r=JZS_R
    ) if np.isfinite(tval) else np.nan
    for tval in goal_t
], dtype=float)

print("\n" + "=" * 74)
print("Computing JZS BF10 for Responsibility")
print("=" * 74)
resp_bf = np.array([
    pg.bayesfactor_ttest(
        t=float(tval), nx=n_subjects, alternative="two-sided", r=JZS_R
    ) if np.isfinite(tval) else np.nan
    for tval in resp_t
], dtype=float)

# Avoid +inf in log plots while preserving raw BF values in the CSV.
goal_logbf = np.log10(np.clip(goal_bf, 1e-300, 1e300))
resp_logbf = np.log10(np.clip(resp_bf, 1e-300, 1e300))


# =====================================================================
# 13. CLASSIFY ALL ROIs
# =====================================================================

classes = [
    classify_roi(gbf, rbf, gt, rt)
    for gbf, rbf, gt, rt in zip(goal_bf, resp_bf, goal_t, resp_t)
]

result_all = pd.DataFrame({
    "roi": common_rois_ordered,
    "n": n_subjects,

    "goal_mean_beta": goal_mean,
    "goal_sd_beta": goal_sd,
    "goal_t": goal_t,
    "goal_p_two_sided": goal_p,
    "goal_cohen_dz": goal_dz,
    "goal_bf10": goal_bf,
    "goal_log10_bf10": goal_logbf,
    "goal_evidence": [evidence_state(x) for x in goal_bf],

    "responsibility_mean_beta": resp_mean,
    "responsibility_sd_beta": resp_sd,
    "responsibility_t": resp_t,
    "responsibility_p_two_sided": resp_p,
    "responsibility_cohen_dz": resp_dz,
    "responsibility_bf10": resp_bf,
    "responsibility_log10_bf10": resp_logbf,
    "responsibility_evidence": [evidence_state(x) for x in resp_bf],

    "bf_class": classes,
    "bf_class_broad": [broad_class(x) for x in classes],
})

result_all["is_schaefer200"] = result_all["roi"].isin(cortical_rois)
result_all["is_primary_neural215"] = result_all["roi"].isin(neural_rois)

result_neural = (
    result_all[result_all["is_primary_neural215"]]
    .copy()
    .reset_index(drop=True)
)

result_cortical = (
    result_all[result_all["is_schaefer200"]]
    .copy()
    .set_index("roi")
    .loc[cortical_rois]
    .reset_index()
)

result_all.to_csv(
    OUT_DIR / "bf_classification_all221.csv",
    index=False,
)
result_neural.to_csv(
    OUT_DIR / "bf_classification_neural215.csv",
    index=False,
)
result_cortical.to_csv(
    OUT_DIR / "bf_classification_cortical200.csv",
    index=False,
)


# =====================================================================
# 14. COUNT SUMMARY
# =====================================================================

fine_order = [
    "Goal-specific",
    "Responsibility-specific",
    "Both-same-sign",
    "Both-opposite-sign",
    "Uncertain",
]

fine_counts = (
    result_neural["bf_class"]
    .value_counts()
    .reindex(fine_order, fill_value=0)
)

broad_counts = (
    result_neural["bf_class_broad"]
    .value_counts()
    .reindex(
        ["Goal-specific", "Responsibility-specific", "Both", "Uncertain"],
        fill_value=0,
    )
)

summary_rows = []

for cls, n in broad_counts.items():
    summary_rows.append({
        "level": "broad",
        "class": cls,
        "n_rois": int(n),
        "percent_of_neural_rois": 100.0 * n / len(result_neural),
    })

for cls, n in fine_counts.items():
    summary_rows.append({
        "level": "fine",
        "class": cls,
        "n_rois": int(n),
        "percent_of_neural_rois": 100.0 * n / len(result_neural),
    })

count_df = pd.DataFrame(summary_rows)
count_df.to_csv(
    OUT_DIR / "bf_class_counts_neural215.csv",
    index=False,
)

print("\nPrimary 215-ROI BF classification:")
print(count_df.to_string(index=False))


# =====================================================================
# 15. FETCH SCHAEFER ATLAS AND BUILD CATEGORICAL CLASS MAP
# =====================================================================

print("\n" + "=" * 74)
print("Creating Schaefer-200 cortical BF-class map")
print("=" * 74)

schaefer = datasets.fetch_atlas_schaefer_2018(
    n_rois=N_SCHAEFER,
    yeo_networks=7,
    resolution_mm=2,
)

atlas_img = nib.load(schaefer.maps)
atlas_labels_all = decode_labels(schaefer.labels)

if len(atlas_labels_all) == N_SCHAEFER + 1:
    first_label = atlas_labels_all[0].strip().lower()
    if first_label in {"background", "bg"}:
        atlas_labels = atlas_labels_all[1:]
        print("Removed atlas Background label.")
    else:
        raise ValueError(
            f"Atlas returned {len(atlas_labels_all)} labels, but first label "
            f"is not recognized as Background: {atlas_labels_all[0]!r}"
        )
elif len(atlas_labels_all) == N_SCHAEFER:
    atlas_labels = atlas_labels_all
else:
    raise ValueError(
        f"Unexpected number of Schaefer labels: {len(atlas_labels_all)}."
    )

verify_schaefer_order(
    beta_columns=common_rois_ordered,
    atlas_labels=atlas_labels,
)

# 0 uncertain/background
# 1 Goal-specific
# 2 Responsibility-specific
# 3 Both-same-sign
# 4 Both-opposite-sign
CLASS_CODE = {
    "Uncertain": 0,
    "Goal-specific": 1,
    "Responsibility-specific": 2,
    "Both-same-sign": 3,
    "Both-opposite-sign": 4,
}

cortical_codes = np.array(
    [CLASS_CODE[x] for x in result_cortical["bf_class"]],
    dtype=int,
)

class_img = parcel_values_to_nifti(cortical_codes, atlas_img)
class_img.to_filename(
    OUT_DIR / "bf_class_cortical200.nii.gz"
)


# =====================================================================
# 16. SELECT FOUR ROIs FOR PANEL b
# =====================================================================

if SELECTED_ROIS:
    missing = [r for r in SELECTED_ROIS if r not in set(result_neural["roi"])]
    if missing:
        raise ValueError(
            "The following SELECTED_ROIS are not found in the neural ROI list:\n"
            + "\n".join(missing)
        )
    selected_rois = SELECTED_ROIS[:4]
else:
    selected_rois = auto_select_rois(result_neural, n_select=4)

selected_df = (
    result_neural
    .set_index("roi")
    .loc[selected_rois]
    .reset_index()
)

selected_df.to_csv(
    OUT_DIR / "bf_selected_rois.csv",
    index=False,
)

print("\nPanel-b selected ROIs:")
for _, row in selected_df.iterrows():
    print(
        f"  {row['roi']}: {row['bf_class']} | "
        f"Goal BF10={row['goal_bf10']:.4g}, "
        f"Resp BF10={row['responsibility_bf10']:.4g}"
    )


# =====================================================================
# 17. COMBINED FIGURE
# =====================================================================

print("\n" + "=" * 74)
print("Creating combined BF figure")
print("=" * 74)

fig = plt.figure(figsize=(11.0, 8.2))

outer = fig.add_gridspec(
    nrows=2,
    ncols=2,
    height_ratios=[1.20, 1.0],
    width_ratios=[1.65, 1.0],
    hspace=0.46,
    wspace=0.24,
)

# a: surface map spans both columns.
draw_surface_panel(
    fig,
    outer[0, :],
    class_img,
)

# b: BF points
ax_b = fig.add_subplot(outer[1, 0])
draw_bf_panel(ax_b, selected_df)

# c: Venn
ax_c = fig.add_subplot(outer[1, 1])

counts = {
    "total": len(result_neural),
    "Goal-specific": int(broad_counts["Goal-specific"]),
    "Responsibility-specific": int(broad_counts["Responsibility-specific"]),
    "Both": int(broad_counts["Both"]),
    "Both-same-sign": int(fine_counts["Both-same-sign"]),
    "Both-opposite-sign": int(fine_counts["Both-opposite-sign"]),
    "Uncertain": int(broad_counts["Uncertain"]),
}
draw_venn_panel(ax_c, counts)

# Panel labels + titles
add_panel_letter(
    fig, 0.035, 0.975,
    "a",
    "BF-based classification of cortical ROIs",
)
add_panel_letter(
    fig, 0.035, 0.438,
    "b",
    "Group-level Bayes factors in selected ROIs",
)
add_panel_letter(
    fig, 0.655, 0.438,
    "c",
    "Distribution of BF classes across neural ROIs",
)

# A compact figure-level note.
fig.text(
    0.50, 0.015,
    r"JZS prior scale $r=\sqrt{2}/2$; "
    r"effect evidence: $BF_{10}>5$; null evidence: $BF_{10}<1/5$. "
    "Surface map: Schaefer-200 cortex; count summary: 215 neural ROIs.",
    ha="center",
    va="bottom",
    fontsize=8.5,
    color=DARK_GRAY,
)

fig.savefig(
    OUT_DIR / "Fig_BF_shared_distinct_revised.svg",
    bbox_inches="tight",
)
fig.savefig(
    OUT_DIR / "Fig_BF_shared_distinct_revised.pdf",
    bbox_inches="tight",
)
fig.savefig(
    OUT_DIR / "Fig_BF_shared_distinct_revised.png",
    dpi=600,
    bbox_inches="tight",
)

plt.close(fig)


# =====================================================================
# 18. FINAL CONSOLE SUMMARY
# =====================================================================

print("\n" + "=" * 74)
print("DONE")
print("=" * 74)

print(f"Output directory (new; existing results untouched):\n{OUT_DIR}\n")

print("Main outputs:")
print("  bf_classification_all221.csv")
print("  bf_classification_neural215.csv")
print("  bf_classification_cortical200.csv")
print("  bf_class_counts_neural215.csv")
print("  bf_selected_rois.csv")
print("  bf_class_cortical200.nii.gz")
print("  Fig_BF_shared_distinct_revised.svg / .pdf / .png")

print("\nInterpretation reminder:")
print(
    "  'Specific' requires evidence for an effect in one dimension "
    "AND evidence for the null in the other."
)
print(
    "  'Both-opposite-sign' means both dimensions have supported effects "
    "in the same ROI but with opposite beta signs; do not describe this "
    "as a shared same-direction response."
)
