# -*- coding: utf-8 -*-
"""
Recompute Table 1 and Table 2 from the original behavioral time-series files.

This script follows the aggregation workflow in the earlier
per_second_binomial_four_predictors.py:

1. Read all CSV/XLS/XLSX files in goalsec1/ and zrgysec1/.
2. Identify each file's time and rating columns.
3. Convert rating timestamps to the nearest integer second using floor(time + 0.5).
4. If one file has multiple observations in the same second, average those observations.
5. Outer-merge the time series across files and take the mean across available files
   at each second (pandas mean skips missing values).
6. Restrict the model time axis to the overlap between the goal and responsibility
   time-series ranges, then align pause counts to the same seconds.
7. Fit both binomial GLMs using the same pause outcome, denominator, linear time trend,
   HAC robust covariance approach, and pause time-binning method.

Table 1:
    pause_proportion ~ goal + responsibility + time_c

Table 2:
    pause_proportion ~ Goal_Facilitation_c + Goal_Obstruction_c
                       + Agency_Self_c + Agency_Other_c + time_c

Important:
- This script does not use w3.csv.
- It does not choose a model or setting based on whether a result is significant.
- The model outputs are the results; nonsignificant findings must be reported as such.
- Confirm that each of the 47 participants was in the pause risk set for every modeled second.
- Confirm that pause timestamps are video playback seconds and that floor() is the correct
  binning rule. These settings are inherited from the previous script, not independently
  verified against the raw files.
"""

from pathlib import Path
import re
import warnings

import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf
from statsmodels.stats.multitest import multipletests


# ============================================================
# 1. Configuration: edit BASE_DIR if your folders are elsewhere
# ============================================================
BASE_DIR = Path(r"C:\Users\tsuki\数据2")
GOAL_DIR = BASE_DIR / "goalsec1"
RESP_DIR = BASE_DIR / "zrgysec1"
PAUSE_DIR = BASE_DIR / "emosec"
OUTPUT_DIR = BASE_DIR / "pause_binomial_two_models_original_data"

N_TOTAL_PARTICIPANTS = 47

GOAL_MEAN_FILE = None
RESP_MEAN_FILE = None

PAUSE_TIME_COLUMN = "time"
PAUSE_TIME_IS_PLAYBACK_SECONDS = True
PAUSE_BIN_METHOD = "floor"   # "floor" or "round"; inherited from the earlier script
CONTROL_LINEAR_TIME = True
HAC_MAXLAGS = None           # None: max(1, min(20, round(n_seconds ** (1/3))))
ALPHA = 0.05
MIN_SECONDS_FOR_MODEL = 20

TIME_NAMES = {
    "time", "time_s", "timestamp", "second", "seconds", "视频时间", "时间"
}
VALUE_NAMES = {
    "mean", "mean_rating", "rating_mean", "value", "rating", "score",
    "goal", "responsibility", "目标评价", "责任归因", "均值", "评分",
    "zrgy", "zrgysec1", "goalsec1"
}


# ============================================================
# 2. Read files and reproduce the original aggregation
# ============================================================
def read_table(path):
    path = Path(path)
    if path.suffix.lower() == ".csv":
        last_error = None
        for encoding in ("utf-8-sig", "utf-8", "gb18030"):
            try:
                return pd.read_csv(path, encoding=encoding)
            except Exception as exc:
                last_error = exc
        raise last_error
    if path.suffix.lower() in (".xlsx", ".xls"):
        return pd.read_excel(path)
    raise ValueError(f"Unsupported file format: {path}")


def data_files(folder):
    files = []
    for pattern in ("*.csv", "*.xlsx", "*.xls"):
        files.extend(Path(folder).glob(pattern))
    return sorted(p for p in files if not p.name.startswith("~$"))


def choose_time_column(df):
    for col in df.columns:
        if str(col).strip().lower() in TIME_NAMES:
            return col
    return df.columns[0]


def choose_value_column(df, time_col):
    other_cols = [col for col in df.columns if col != time_col]
    for col in other_cols:
        if str(col).strip().lower() in VALUE_NAMES:
            return col
    for col in other_cols:
        if pd.to_numeric(df[col], errors="coerce").notna().sum() > 0:
            return col
    raise ValueError(f"Could not identify a numeric rating column. Columns: {list(df.columns)}")


def load_mean_timeseries(folder, label, explicit_file=None):
    """
    Reproduces the prior script's rating-series aggregation:
    nearest-second rounding; within-file duplicate-second mean; across-file
    per-second mean after outer merge, ignoring missing values.
    """
    if explicit_file is not None:
        files = [Path(explicit_file)]
        if not files[0].exists():
            raise FileNotFoundError(f"File not found: {files[0]}")
    else:
        if not Path(folder).exists():
            raise FileNotFoundError(f"Directory not found: {folder}")
        files = data_files(folder)
        if not files:
            raise FileNotFoundError(f"No CSV/XLS/XLSX files in {folder}")

    series_list = []
    logs = []

    for path in files:
        raw = read_table(path)
        if raw.shape[1] < 2:
            logs.append({"file": path.name, "status": "skipped: fewer than two columns"})
            continue

        tcol = choose_time_column(raw)
        vcol = choose_value_column(raw, tcol)

        tmp = pd.DataFrame({
            "time": pd.to_numeric(raw[tcol], errors="coerce"),
            "value": pd.to_numeric(raw[vcol], errors="coerce")
        }).dropna()

        if tmp.empty:
            logs.append({"file": path.name, "status": "skipped: no numeric data"})
            continue

        # Same rule as the earlier four-predictor script:
        # nearest integer second, then mean duplicate observations within file.
        tmp["time"] = np.floor(tmp["time"] + 0.5).astype(int)
        tmp = tmp.groupby("time", as_index=False)["value"].mean()

        col = f"value_{len(series_list)}"
        series_list.append(tmp.rename(columns={"value": col}))
        logs.append({
            "file": path.name,
            "status": "loaded",
            "time_column": str(tcol),
            "value_column": str(vcol),
            "n_seconds": len(tmp)
        })

    if not series_list:
        raise ValueError(f"No usable time series found in {folder}")

    merged = series_list[0]
    for series in series_list[1:]:
        merged = merged.merge(series, on="time", how="outer")

    value_cols = [col for col in merged.columns if col.startswith("value_")]
    merged[label] = merged[value_cols].mean(axis=1)  # same across-file mean as original
    out = merged[["time", label]].dropna().sort_values("time").reset_index(drop=True)

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(logs).to_csv(
        OUTPUT_DIR / f"input_files_{label}.csv",
        index=False, encoding="utf-8-sig"
    )

    print(
        f"[{label}] files={len(files)}, valid seconds={len(out)}, "
        f"range={out.time.min()}–{out.time.max()}"
    )
    if len(files) > 1:
        print(
            f"Note: {label} has multiple files; their per-second values were "
            "aligned and averaged, following the previous script."
        )
    return out


def subject_id_from_filename(filename):
    # Exactly the ID parsing rule from the previous four-predictor script.
    stem = Path(filename).stem.lower()
    nums = re.findall(r"\d+", stem)
    if len(nums) >= 2:
        return "_".join(nums[-2:])
    if len(nums) == 1:
        return nums[0].lstrip("0") or "0"
    return re.sub(r"[^a-z0-9]+", "_", stem).strip("_")


def load_pause_events(folder):
    if not PAUSE_TIME_IS_PLAYBACK_SECONDS:
        raise ValueError(
            "Pause timestamps have not been confirmed as video playback seconds. "
            "Convert them to the video time axis before fitting."
        )

    files = data_files(folder)
    if not files:
        raise FileNotFoundError(f"No pause data files found in {folder}")

    events, subject_ids, skipped = [], set(), []

    for path in files:
        sid = subject_id_from_filename(path.name)
        try:
            raw = read_table(path)
            if raw.empty:
                skipped.append({"file": path.name, "reason": "empty file"})
                continue

            tcol = PAUSE_TIME_COLUMN if PAUSE_TIME_COLUMN in raw.columns else choose_time_column(raw)
            times = pd.to_numeric(raw[tcol], errors="coerce").dropna()
            if times.empty:
                skipped.append({"file": path.name, "reason": "no valid timestamps"})
                continue

            subject_ids.add(sid)

            if PAUSE_BIN_METHOD == "floor":
                seconds = np.floor(times.to_numpy()).astype(int)
            elif PAUSE_BIN_METHOD == "round":
                seconds = np.floor(times.to_numpy() + 0.5).astype(int)
            else:
                raise ValueError("PAUSE_BIN_METHOD must be 'floor' or 'round'.")

            # As in the prior script, a participant contributes at most one pause
            # per integer second.
            for sec in np.unique(seconds):
                events.append({"subject_id": sid, "time": int(sec)})

        except Exception as exc:
            skipped.append({"file": path.name, "reason": repr(exc)})

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    if skipped:
        pd.DataFrame(skipped).to_csv(
            OUTPUT_DIR / "skipped_pause_files.csv",
            index=False, encoding="utf-8-sig"
        )

    pauses = pd.DataFrame(events)
    if pauses.empty:
        raise ValueError("No valid pause events were read.")

    pauses = pauses.drop_duplicates(["subject_id", "time"])
    print(f"[pause] unique participant IDs={len(subject_ids)}; participant-second rows={len(pauses)}")

    if len(subject_ids) != N_TOTAL_PARTICIPANTS:
        warnings.warn(
            f"Detected {len(subject_ids)} unique pause IDs, but configured denominator is "
            f"{N_TOTAL_PARTICIPANTS}. Verify filename parsing and sample size."
        )

    return pauses, subject_ids


# ============================================================
# 3. Align predictors and pause outcome on the same seconds
# ============================================================
def build_second_level_data(goal_ts, resp_ts, pause_events):
    start = max(int(goal_ts["time"].min()), int(resp_ts["time"].min()))
    end = min(int(goal_ts["time"].max()), int(resp_ts["time"].max()))
    if end <= start:
        raise ValueError("Goal and responsibility series have no overlapping time range.")

    data = pd.DataFrame({"time": np.arange(start, end + 1, dtype=int)})
    data = data.merge(goal_ts, on="time", how="left")
    data = data.merge(resp_ts, on="time", how="left")

    # Drop seconds where either predictor is missing rather than imputing them.
    data = data.dropna(subset=["goal", "responsibility"]).copy()

    counts = (
        pause_events.groupby("time")["subject_id"]
        .nunique()
        .rename("pause_count")
        .reset_index()
    )
    data = data.merge(counts, on="time", how="left")
    data["pause_count"] = data["pause_count"].fillna(0).astype(int)
    data["n_total"] = N_TOTAL_PARTICIPANTS
    data["nonpause_count"] = data["n_total"] - data["pause_count"]

    if (data["nonpause_count"] < 0).any():
        raise ValueError("Pause count exceeds the configured denominator; check IDs and N.")

    data["pause_proportion"] = data["pause_count"] / data["n_total"]
    data["time_c"] = data["time"] - data["time"].mean()

    # Split directions from the same aggregated series, as in the prior script.
    data["Goal_Facilitation"] = data["goal"].clip(lower=0)
    data["Goal_Obstruction"] = (-data["goal"]).clip(lower=0)
    data["Agency_Self"] = data["responsibility"].clip(lower=0)
    data["Agency_Other"] = (-data["responsibility"]).clip(lower=0)

    for col in [
        "Goal_Facilitation", "Goal_Obstruction", "Agency_Self", "Agency_Other"
    ]:
        data[f"{col}_c"] = data[col] - data[col].mean()

    return data.reset_index(drop=True)


# ============================================================
# 4. Model fitting: same binomial GLM/HAC setup for both models
# ============================================================
def hac_lags(n):
    if HAC_MAXLAGS is not None:
        return int(HAC_MAXLAGS)
    return max(1, min(20, int(round(n ** (1 / 3)))))


def fit_binomial_glm(data, predictor_terms, model_name, fdr_terms):
    """
    Same GLM approach as the previous script:
    response is the pause proportion with n_total frequency weights,
    Binomial family, HAC covariance. BH-FDR is applied only to appraisal predictors.
    """
    terms = list(predictor_terms)
    if CONTROL_LINEAR_TIME:
        terms.append("time_c")

    formula = "pause_proportion ~ " + " + ".join(terms)
    fitted = smf.glm(
        formula=formula,
        data=data,
        family=sm.families.Binomial(),
        freq_weights=data["n_total"]
    ).fit(
        cov_type="HAC",
        cov_kwds={"maxlags": hac_lags(len(data))}
    )

    ci = fitted.conf_int()
    rows = []
    for term in fitted.params.index:
        beta = float(fitted.params[term])
        se = float(fitted.bse[term])
        pval = float(fitted.pvalues[term])
        low, high = map(float, ci.loc[term].tolist())
        rows.append({
            "model": model_name,
            "term": term,
            "B_log_odds": beta,
            "HAC_SE": se,
            "z": beta / se if se > 0 else np.nan,
            "p_raw": pval,
            "CI95_B_low": low,
            "CI95_B_high": high,
            "OR": np.exp(beta),
            "CI95_OR_low": np.exp(low),
            "CI95_OR_high": np.exp(high),
            "FDR_q": np.nan,
            "FDR_significant": "not corrected"
        })

    coef_table = pd.DataFrame(rows)
    mask = coef_table["term"].isin(fdr_terms)
    if mask.any():
        reject, q_values, _, _ = multipletests(
            coef_table.loc[mask, "p_raw"].to_numpy(),
            alpha=ALPHA,
            method="fdr_bh"
        )
        coef_table.loc[mask, "FDR_q"] = q_values
        coef_table.loc[mask, "FDR_significant"] = np.where(reject, "yes", "no")

    summary = {
        "model": model_name,
        "formula": formula,
        "n_seconds": len(data),
        "participant_denominator_per_second": N_TOTAL_PARTICIPANTS,
        "total_pause_participant_seconds": int(data["pause_count"].sum()),
        "HAC_maxlags": hac_lags(len(data)),
        "log_likelihood": float(fitted.llf),
        "AIC": float(fitted.aic),
        "BIC": float(fitted.bic),
        "FDR_method": "Benjamini-Hochberg",
        "FDR_family": "; ".join(fdr_terms)
    }

    return fitted, coef_table, summary


def main():
    for folder in (GOAL_DIR, RESP_DIR, PAUSE_DIR):
        if not folder.exists():
            raise FileNotFoundError(
                f"Directory not found: {folder}. Edit BASE_DIR or folder settings."
            )

    goal_ts = load_mean_timeseries(GOAL_DIR, "goal", GOAL_MEAN_FILE)
    resp_ts = load_mean_timeseries(RESP_DIR, "responsibility", RESP_MEAN_FILE)
    pause_events, subject_ids = load_pause_events(PAUSE_DIR)
    data = build_second_level_data(goal_ts, resp_ts, pause_events)

    if len(data) < MIN_SECONDS_FOR_MODEL:
        raise ValueError(f"Too few aligned seconds for model fitting: {len(data)}")

    # Table 1: unsplit bipolar ratings. Same per-second data and outcome as Table 2.
    model1, coef1, summary1 = fit_binomial_glm(
        data=data,
        predictor_terms=["goal", "responsibility"],
        model_name="Table 1: two bipolar predictors",
        fdr_terms=["goal", "responsibility"]
    )

    # Table 2: four directional components derived from the same averaged series.
    model2, coef2, summary2 = fit_binomial_glm(
        data=data,
        predictor_terms=[
            "Goal_Facilitation_c",
            "Goal_Obstruction_c",
            "Agency_Self_c",
            "Agency_Other_c"
        ],
        model_name="Table 2: four directional predictors",
        fdr_terms=[
            "Goal_Facilitation_c",
            "Goal_Obstruction_c",
            "Agency_Self_c",
            "Agency_Other_c"
        ]
    )

    # Save common aligned data and both model-specific tables.
    data.to_csv(
        OUTPUT_DIR / "per_second_data_original_aggregated.csv",
        index=False, encoding="utf-8-sig"
    )
    coef1.to_csv(
        OUTPUT_DIR / "table1_two_predictors_coefficients.csv",
        index=False, encoding="utf-8-sig"
    )
    coef2.to_csv(
        OUTPUT_DIR / "table2_four_predictors_coefficients.csv",
        index=False, encoding="utf-8-sig"
    )

    summary_df = pd.DataFrame([summary1, summary2])
    excel_path = OUTPUT_DIR / "two_models_original_data_results.xlsx"
    with pd.ExcelWriter(excel_path, engine="openpyxl") as writer:
        summary_df.to_excel(writer, sheet_name="Model_summary", index=False)
        coef1.to_excel(writer, sheet_name="Table1_two_predictors", index=False)
        coef2.to_excel(writer, sheet_name="Table2_four_predictors", index=False)
        data.to_excel(writer, sheet_name="Aligned_second_data", index=False)

    with open(OUTPUT_DIR / "analysis_summary.txt", "w", encoding="utf-8") as f:
        f.write("Two binomial logistic regression models from original rating files\n")
        f.write("=" * 78 + "\n")
        f.write("Aggregation follows the previous per_second_binomial_four_predictors.py.\n")
        f.write("No w3.csv is read by this script.\n")
        f.write("Per-file timestamps: nearest-second rounding via floor(time + 0.5).\n")
        f.write("Within-file duplicate seconds: mean.\n")
        f.write("Across-file per-second aggregation: mean of available files after outer merge.\n")
        f.write("Model time range: overlap of goal and responsibility time-series ranges.\n")
        f.write("Pause count: unique participant IDs with at least one pause in each second.\n")
        f.write(f"Configured denominator: {N_TOTAL_PARTICIPANTS}\n")
        f.write(f"Detected pause IDs: {len(subject_ids)}\n")
        f.write(f"Aligned/model seconds: {len(data)}\n")
        f.write(f"HAC maxlags: {hac_lags(len(data))}\n")
        f.write("No setting was selected based on significance; report the observed results.\n\n")

        f.write("\n" + "=" * 78 + "\nTABLE 1: TWO BIPOLAR PREDICTORS\n")
        f.write("=" * 78 + "\n")
        f.write(model1.summary().as_text() + "\n\n")
        f.write(coef1.to_string(index=False) + "\n")

        f.write("\n" + "=" * 78 + "\nTABLE 2: FOUR DIRECTIONAL PREDICTORS\n")
        f.write("=" * 78 + "\n")
        f.write(model2.summary().as_text() + "\n\n")
        f.write(coef2.to_string(index=False) + "\n")

        f.write("\nRequired checks before reporting:\n")
        f.write("1. Confirm pause timestamps are video playback seconds.\n")
        f.write("2. Confirm floor/round binning matches the source-data procedure.\n")
        f.write("3. Confirm 47 participants were all at risk in every modeled second.\n")
        f.write("4. Confirm participant IDs are parsed correctly from filenames.\n")
        f.write("5. Compare aggregation logs with the actual raw data files.\n")

    print("\nBoth models finished.")
    print(f"Output folder: {OUTPUT_DIR}")
    print(f"Excel results: {excel_path}")
    print(f"Table 1 coefficients: {OUTPUT_DIR / 'table1_two_predictors_coefficients.csv'}")
    print(f"Table 2 coefficients: {OUTPUT_DIR / 'table2_four_predictors_coefficients.csv'}")
    print("Do not interpret statistical significance as guaranteed; use the computed results.")


if __name__ == "__main__":
    main()
