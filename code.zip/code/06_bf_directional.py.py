# -*- coding: utf-8 -*-
"""
bf_directional_classification_and_figure.py
===========================================
Bayes-factor classification for within-dimension directional effects.

Inputs
------
glm_layer2_direction_controlled/
    beta_goal_facil.csv
    beta_goal_block.csv
    beta_self_resp.csv
    beta_other_resp.csv

Goal classification
-------------------
BF_facil > 5 and BF_block > 5:
    Both
BF_facil > 5 and BF_block < .2:
    Facilitation-specific
BF_facil < .2 and BF_block > 5:
    Obstruction-specific
otherwise:
    Uncertain

Responsibility classification
-----------------------------
BF_self > 5 and BF_other > 5:
    Both
BF_self > 5 and BF_other < .2:
    Self-specific
BF_self < .2 and BF_other > 5:
    Other-specific
otherwise:
    Uncertain

Group t-tests use scipy.stats.ttest_1samp; BF10 uses Pingouin bayesfactor_ttest for two-sided JZS tests, r=sqrt(2)/2.

Outputs
-------
glm_layer2_direction_controlled/BF_directional_pingouin_scipy/
    bf_goal_directions_all221.csv
    bf_goal_directions_neural215.csv
    bf_goal_directions_cortical200.csv
    bf_goal_direction_counts.csv

    bf_responsibility_directions_all221.csv
    bf_responsibility_directions_neural215.csv
    bf_responsibility_directions_cortical200.csv
    bf_responsibility_direction_counts.csv

    Fig_BF_goal_directions.svg/.pdf/.png
    Fig_BF_responsibility_directions.svg/.pdf/.png
"""

from pathlib import Path
import re
import warnings

import numpy as np
import pandas as pd
from scipy import stats
import pingouin as pg

import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from matplotlib.patches import Patch

import nibabel as nib
from nilearn import datasets, image, plotting, surface


# ============================================================
# 1. Paths and settings
# ============================================================

RESULT_DIR = Path(r"C:\Users\tsuki\glm_layer2_direction_controlled")
OUT_DIR = RESULT_DIR / "BF_directional_pingouin_scipy"
OUT_DIR.mkdir(parents=True, exist_ok=True)

GOAL_FACIL_FILE = RESULT_DIR / "beta_goal_facil.csv"
GOAL_BLOCK_FILE = RESULT_DIR / "beta_goal_block.csv"
SELF_RESP_FILE = RESULT_DIR / "beta_self_resp.csv"
OTHER_RESP_FILE = RESULT_DIR / "beta_other_resp.csv"

BF_EFFECT = 5.0
BF_NULL = 1.0 / 5.0
JZS_R = np.sqrt(2.0) / 2.0

N_SCHAEFER = 200
N_EXPECTED_ALL = 221
N_EXPECTED_NEURAL = 215
SURFACE_MESH = "fsaverage5"

# Plotting colors are left to Matplotlib's default cycle.
# We use ListedColormap from default cycle colors, without hard-coding RGB values.
default_colors = plt.rcParams["axes.prop_cycle"].by_key()["color"]
CLASS_COLORS = default_colors[:3]


# ============================================================
# 2. Non-neural / redundant Harvard-Oxford entries
# ============================================================

NON_NEURAL_HO = {
    "Left Cerebral White Matter",
    "Left Cerebral Cortex",
    "Left Lateral Ventrical",
    "Left Lateral Ventricle",
    "Right Cerebral White Matter",
    "Right Cerebral Cortex",
    "Right Lateral Ventricle",
}


# ============================================================
# 3. Helpers
# ============================================================

def read_beta_matrix(path: Path) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(
            f"Cannot find:\n{path}\n"
            "Edit RESULT_DIR at the top of this script."
        )

    df = pd.read_csv(path, index_col=0)
    df = df.apply(pd.to_numeric, errors="coerce")
    df = df.dropna(axis=1, how="all")

    if df.isna().any().any():
        bad = np.argwhere(df.isna().to_numpy())
        i, j = bad[0]
        raise ValueError(
            f"{path.name} contains NaN/non-numeric data at "
            f"subject={df.index[i]}, ROI={df.columns[j]}."
        )

    return df


def normalize_roi_name(name):
    return str(name).strip()


def is_schaefer(roi):
    return normalize_roi_name(roi).startswith("7Networks_")


def is_non_neural_ho(roi):
    return normalize_roi_name(roi) in NON_NEURAL_HO


def get_roi_sets(columns):
    cols = [normalize_roi_name(c) for c in columns]

    cortical = [c for c in cols if is_schaefer(c)]
    neural = [
        c for c in cols
        if is_schaefer(c) or (not is_non_neural_ho(c))
    ]

    if len(cortical) != N_SCHAEFER:
        warnings.warn(
            f"Expected {N_SCHAEFER} cortical ROIs, found {len(cortical)}."
        )

    if len(neural) != N_EXPECTED_NEURAL:
        warnings.warn(
            f"Expected {N_EXPECTED_NEURAL} neural ROIs, found {len(neural)}."
        )

    return cortical, neural


def one_sample_stats(matrix):
    """Descriptive statistics plus SciPy's established one-sample t-test.

    Parameters
    ----------
    matrix : array-like, shape (participants, ROIs)
        Participant-level beta values. Missing values are not silently omitted;
        the function raises an error so that N remains consistent with the BF test.

    Returns
    -------
    means, sds, tvals, pvals, dz : ndarray
        Per-ROI mean, sample SD, t statistic, two-sided p value, and Cohen's dz.
    """
    matrix = np.asarray(matrix, dtype=float)
    if matrix.ndim != 2:
        raise ValueError(f"Expected a participants-by-ROIs matrix; got shape {matrix.shape}.")
    if not np.isfinite(matrix).all():
        raise ValueError("Beta matrix contains NaN or infinite values; resolve these before analysis.")

    means = np.mean(matrix, axis=0)
    sds = np.std(matrix, axis=0, ddof=1)

    # Mature, library-provided inferential test; two-sided one-sample t-test against zero.
    test = stats.ttest_1samp(matrix, popmean=0.0, axis=0, alternative="two-sided", nan_policy="raise")
    tvals = np.asarray(test.statistic, dtype=float)
    pvals = np.asarray(test.pvalue, dtype=float)

    # Cohen's dz for a one-sample test against zero: mean / sample SD.
    with np.errstate(divide="ignore", invalid="ignore"):
        dz = means / sds

    return means, sds, tvals, pvals, dz


# Bayes factors are computed directly with Pingouin's built-in
# bayesfactor_ttest function; no custom BF calculation function is used.


def evidence_state(bf):
    if not np.isfinite(bf):
        return "missing"
    if bf > BF_EFFECT:
        return "effect"
    if bf < BF_NULL:
        return "null"
    return "uncertain"


def classify_pair(bf_a, bf_b, t_a, t_b, specific_a, specific_b):
    """
    Returns fine class and broad class.
    Fine class splits Both into same-sign/opposite-sign for description.
    """
    a = evidence_state(bf_a)
    b = evidence_state(bf_b)

    if a == "effect" and b == "effect":
        if np.sign(t_a) == np.sign(t_b):
            return "Both-same-sign", "Both"
        return "Both-opposite-sign", "Both"

    if a == "effect" and b == "null":
        return specific_a, specific_a

    if a == "null" and b == "effect":
        return specific_b, specific_b

    return "Uncertain", "Uncertain"


def decode_labels(labels):
    out = []
    for x in labels:
        if isinstance(x, bytes):
            out.append(x.decode("utf-8"))
        else:
            out.append(str(x))
    return out


def normalize_label(x):
    s = str(x).lower()
    s = s.replace("schaefer", "")
    s = s.replace("roi", "")
    s = re.sub(r"[^a-z0-9]", "", s)
    return s


def verify_schaefer_order(beta_columns, atlas_labels):
    beta_first = list(beta_columns[:N_SCHAEFER])

    if len(atlas_labels) != N_SCHAEFER:
        raise ValueError(
            f"Atlas labels={len(atlas_labels)}, expected {N_SCHAEFER}."
        )

    ok = []
    for b, a in zip(beta_first, atlas_labels):
        nb = normalize_label(b)
        na = normalize_label(a)
        ok.append((nb == na) or (nb in na) or (na in nb))

    rate = float(np.mean(ok))
    print(f"Schaefer label-order match rate: {rate:.3f}")

    if rate < 0.80:
        raise ValueError(
            "The first 200 beta columns do not match the standard "
            "Schaefer-200 order closely enough."
        )


def parcel_values_to_nifti(parcel_values, atlas_img):
    atlas_data = atlas_img.get_fdata().astype(np.int32)
    out = np.zeros(atlas_data.shape, dtype=np.float32)

    for parcel_index, value in enumerate(parcel_values, start=1):
        out[atlas_data == parcel_index] = float(value)

    return image.new_img_like(atlas_img, out)


def project_discrete_to_surface(stat_img, fsavg, hemi):
    if hemi == "left":
        pial = fsavg.pial_left
        white = fsavg.white_left
    else:
        pial = fsavg.pial_right
        white = fsavg.white_right

    try:
        tex = surface.vol_to_surf(
            stat_img,
            pial,
            inner_mesh=white,
            interpolation="nearest",
        )
    except (TypeError, ValueError):
        warnings.warn(
            "Nilearn does not accept interpolation='nearest'; "
            "falling back to default projection and rounding."
        )
        tex = surface.vol_to_surf(
            stat_img,
            pial,
            inner_mesh=white,
        )

    tex = np.rint(tex)
    tex = np.clip(tex, 0, 3)
    return tex


# ============================================================
# 4. Read and align four beta matrices
# ============================================================

facil_df = read_beta_matrix(GOAL_FACIL_FILE)
block_df = read_beta_matrix(GOAL_BLOCK_FILE)
self_df = read_beta_matrix(SELF_RESP_FILE)
other_df = read_beta_matrix(OTHER_RESP_FILE)

dfs = [facil_df, block_df, self_df, other_df]

common_subjects = list(facil_df.index)
for df in dfs[1:]:
    common_subjects = [s for s in common_subjects if s in df.index]

common_rois = list(facil_df.columns)
for df in dfs[1:]:
    common_rois = [r for r in common_rois if r in df.columns]

if len(common_subjects) < 2:
    raise ValueError("Too few common participants.")
if len(common_rois) == 0:
    raise ValueError("No common ROI columns.")

facil_df = facil_df.loc[common_subjects, common_rois]
block_df = block_df.loc[common_subjects, common_rois]
self_df = self_df.loc[common_subjects, common_rois]
other_df = other_df.loc[common_subjects, common_rois]

n_subjects = len(common_subjects)

print(f"Participants: {n_subjects}")
print(f"ROIs: {len(common_rois)}")
print(f"Pingouin version: {pg.__version__}")

if len(common_rois) != N_EXPECTED_ALL:
    warnings.warn(
        f"Expected {N_EXPECTED_ALL} total ROI columns, found {len(common_rois)}."
    )

cortical_rois, neural_rois = get_roi_sets(common_rois)


# ============================================================
# 5. Generic directional analysis
# ============================================================

def analyze_pair(
    df_a,
    df_b,
    name_a,
    name_b,
    specific_a,
    specific_b,
    prefix,
):
    mean_a, sd_a, t_a, p_a, dz_a = one_sample_stats(df_a.to_numpy(float))
    mean_b, sd_b, t_b, p_b, dz_b = one_sample_stats(df_b.to_numpy(float))

    bf_a = np.array([
        pg.bayesfactor_ttest(
            t=float(tval), nx=n_subjects, alternative="two-sided", r=JZS_R
        ) if np.isfinite(tval) else np.nan
        for tval in t_a
    ], dtype=float)
    bf_b = np.array([
        pg.bayesfactor_ttest(
            t=float(tval), nx=n_subjects, alternative="two-sided", r=JZS_R
        ) if np.isfinite(tval) else np.nan
        for tval in t_b
    ], dtype=float)

    fine_classes = []
    broad_classes = []

    for ba, bb, ta, tb in zip(bf_a, bf_b, t_a, t_b):
        fine, broad = classify_pair(
            ba, bb, ta, tb,
            specific_a=specific_a,
            specific_b=specific_b,
        )
        fine_classes.append(fine)
        broad_classes.append(broad)

    result = pd.DataFrame({
        "roi": common_rois,
        "n": n_subjects,

        f"{name_a}_mean_beta": mean_a,
        f"{name_a}_sd_beta": sd_a,
        f"{name_a}_t": t_a,
        f"{name_a}_p_two_sided": p_a,
        f"{name_a}_cohen_dz": dz_a,
        f"{name_a}_bf10": bf_a,
        f"{name_a}_log10_bf10": np.log10(np.clip(bf_a, 1e-300, 1e300)),
        f"{name_a}_evidence": [evidence_state(x) for x in bf_a],

        f"{name_b}_mean_beta": mean_b,
        f"{name_b}_sd_beta": sd_b,
        f"{name_b}_t": t_b,
        f"{name_b}_p_two_sided": p_b,
        f"{name_b}_cohen_dz": dz_b,
        f"{name_b}_bf10": bf_b,
        f"{name_b}_log10_bf10": np.log10(np.clip(bf_b, 1e-300, 1e300)),
        f"{name_b}_evidence": [evidence_state(x) for x in bf_b],

        "bf_class": fine_classes,
        "bf_class_broad": broad_classes,
    })

    result["is_schaefer200"] = result["roi"].isin(cortical_rois)
    result["is_primary_neural215"] = result["roi"].isin(neural_rois)

    result_all = result.copy()
    result_neural = (
        result[result["is_primary_neural215"]]
        .copy()
        .reset_index(drop=True)
    )
    result_cortical = (
        result[result["is_schaefer200"]]
        .copy()
        .set_index("roi")
        .loc[cortical_rois]
        .reset_index()
    )

    result_all.to_csv(
        OUT_DIR / f"bf_{prefix}_all221.csv",
        index=False,
    )
    result_neural.to_csv(
        OUT_DIR / f"bf_{prefix}_neural215.csv",
        index=False,
    )
    result_cortical.to_csv(
        OUT_DIR / f"bf_{prefix}_cortical200.csv",
        index=False,
    )

    count_order = [specific_a, specific_b, "Both", "Uncertain"]
    counts = (
        result_neural["bf_class_broad"]
        .value_counts()
        .reindex(count_order, fill_value=0)
    )

    count_df = pd.DataFrame({
        "class": counts.index,
        "n_rois": counts.values.astype(int),
        "percent_of_neural_rois": 100.0 * counts.values / len(result_neural),
    })

    count_df.to_csv(
        OUT_DIR / f"bf_{prefix}_counts.csv",
        index=False,
    )

    print(f"\n{prefix}:")
    print(count_df.to_string(index=False))

    return result_all, result_neural, result_cortical, count_df


goal_all, goal_neural, goal_cortical, goal_counts = analyze_pair(
    facil_df,
    block_df,
    name_a="facilitation",
    name_b="obstruction",
    specific_a="Facilitation-specific",
    specific_b="Obstruction-specific",
    prefix="goal_directions",
)

resp_all, resp_neural, resp_cortical, resp_counts = analyze_pair(
    self_df,
    other_df,
    name_a="self",
    name_b="other",
    specific_a="Self-specific",
    specific_b="Other-specific",
    prefix="responsibility_directions",
)


# ============================================================
# 6. Atlas preparation
# ============================================================

schaefer = datasets.fetch_atlas_schaefer_2018(
    n_rois=N_SCHAEFER,
    yeo_networks=7,
    resolution_mm=2,
)

atlas_img = nib.load(schaefer.maps)
atlas_labels_all = decode_labels(schaefer.labels)

if len(atlas_labels_all) == N_SCHAEFER + 1:
    first = atlas_labels_all[0].strip().lower()
    if first in {"background", "bg"}:
        atlas_labels = atlas_labels_all[1:]
    else:
        raise ValueError("Unexpected Schaefer background labeling.")
elif len(atlas_labels_all) == N_SCHAEFER:
    atlas_labels = atlas_labels_all
else:
    raise ValueError(
        f"Unexpected Schaefer label count: {len(atlas_labels_all)}"
    )

verify_schaefer_order(common_rois, atlas_labels)
fsavg = datasets.fetch_surf_fsaverage(mesh=SURFACE_MESH)


# ============================================================
# 7. Publication-style surface + count figure
# ============================================================

def plot_direction_figure(
    result_cortical,
    count_df,
    specific_a,
    specific_b,
    title,
    out_stem,
):
    """
    Map broad classes:
      0 = Uncertain/background
      1 = direction A specific
      2 = direction B specific
      3 = Both
    """
    code_map = {
        "Uncertain": 0,
        specific_a: 1,
        specific_b: 2,
        "Both": 3,
    }

    parcel_codes = (
        result_cortical["bf_class_broad"]
        .map(code_map)
        .fillna(0)
        .to_numpy(float)
    )

    class_img = parcel_values_to_nifti(parcel_codes, atlas_img)

    tex_l = project_discrete_to_surface(class_img, fsavg, "left")
    tex_r = project_discrete_to_surface(class_img, fsavg, "right")

    cmap = ListedColormap(CLASS_COLORS)

    fig = plt.figure(figsize=(14, 7))
    gs = fig.add_gridspec(
        2, 4,
        height_ratios=[2.4, 1.0],
        hspace=0.18,
        wspace=0.02,
    )

    configs = [
        ("left", "lateral", fsavg.infl_left, fsavg.sulc_left, tex_l),
        ("left", "medial", fsavg.infl_left, fsavg.sulc_left, tex_l),
        ("right", "medial", fsavg.infl_right, fsavg.sulc_right, tex_r),
        ("right", "lateral", fsavg.infl_right, fsavg.sulc_right, tex_r),
    ]

    for i, (hemi, view, mesh, sulc, tex) in enumerate(configs):
        ax = fig.add_subplot(gs[0, i], projection="3d")
        plotting.plot_surf_stat_map(
            surf_mesh=mesh,
            stat_map=tex,
            bg_map=sulc,
            hemi=hemi,
            view=view,
            cmap=cmap,
            colorbar=False,
            threshold=0.5,
            vmin=1.0,
            vmax=3.0,
            bg_on_data=False,
            axes=ax,
            figure=fig,
        )
        ax.set_axis_off()

    # Summary counts
    axb = fig.add_subplot(gs[1, :])
    plot_df = count_df[count_df["class"] != "Uncertain"].copy()

    x = np.arange(len(plot_df))
    axb.bar(x, plot_df["n_rois"].to_numpy())
    axb.set_xticks(x)
    axb.set_xticklabels(plot_df["class"].tolist(), fontsize=11)
    axb.set_ylabel("Number of ROIs")
    axb.spines["top"].set_visible(False)
    axb.spines["right"].set_visible(False)

    for xi, n, pct in zip(
        x,
        plot_df["n_rois"],
        plot_df["percent_of_neural_rois"],
    ):
        axb.text(
            xi,
            n + max(1, 0.02 * max(plot_df["n_rois"].max(), 1)),
            f"{int(n)} ({pct:.1f}%)",
            ha="center",
            va="bottom",
            fontsize=10,
        )

    uncertain_row = count_df[count_df["class"] == "Uncertain"]
    if len(uncertain_row):
        n_unc = int(uncertain_row.iloc[0]["n_rois"])
        pct_unc = float(uncertain_row.iloc[0]["percent_of_neural_rois"])
        axb.text(
            0.99,
            0.93,
            f"Uncertain: {n_unc} ({pct_unc:.1f}%)",
            transform=axb.transAxes,
            ha="right",
            va="top",
            fontsize=10,
        )

    legend_handles = [
        Patch(facecolor=CLASS_COLORS[0], label=specific_a),
        Patch(facecolor=CLASS_COLORS[1], label=specific_b),
        Patch(facecolor=CLASS_COLORS[2], label="Both"),
    ]
    fig.legend(
        handles=legend_handles,
        loc="upper center",
        bbox_to_anchor=(0.5, 0.93),
        ncol=3,
        frameon=False,
    )

    fig.suptitle(title, fontsize=16, y=0.99)

    for ext in ["svg", "pdf", "png"]:
        fig.savefig(
            OUT_DIR / f"{out_stem}.{ext}",
            dpi=300 if ext == "png" else None,
            bbox_inches="tight",
        )

    plt.close(fig)


plot_direction_figure(
    goal_cortical,
    goal_counts,
    specific_a="Facilitation-specific",
    specific_b="Obstruction-specific",
    title="Goal congruence: directional Bayes-factor classification",
    out_stem="Fig_BF_goal_directions",
)

plot_direction_figure(
    resp_cortical,
    resp_counts,
    specific_a="Self-specific",
    specific_b="Other-specific",
    title="Responsibility attribution: directional Bayes-factor classification",
    out_stem="Fig_BF_responsibility_directions",
)

print(f"\nOutputs saved to the new folder (existing results untouched):\n{OUT_DIR}")
