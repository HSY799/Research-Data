from pathlib import Path

import re

import warnings



import numpy as np

import pandas as pd

from scipy import stats

from statsmodels.stats.multitest import multipletests



import matplotlib as mpl

import matplotlib.pyplot as plt

from matplotlib.gridspec import GridSpec



import nibabel as nib

from nilearn import datasets, image, plotting, surface





# ============================================================

# 1. Paths and settings

# ============================================================



BETA_DIR = Path(r"C:\Users\tsuki\glm_layer1_goal_resp")



GOAL_BETA_FILE = BETA_DIR / "beta_layer1_goal_resp_goal.csv"

RESP_BETA_FILE = BETA_DIR / "beta_layer1_goal_resp_responsibility.csv"



OUT_DIR = BETA_DIR / "neural_validation_AB"

OUT_DIR.mkdir(parents=True, exist_ok=True)



FDR_ALPHA = 0.01

N_SCHAEFER = 200

N_EXPECTED_ROIS = 221



# Main network plot mode:

# "fdr01" uses the q < .01 thresholded effect maps (closer to the Miao logic)

# "unthresholded" uses the raw cortical t-maps

NETWORK_FIGURE_MODE = "fdr01"



# Figure style

mpl.rcParams["svg.fonttype"] = "none"

mpl.rcParams["pdf.fonttype"] = 42

mpl.rcParams["font.family"] = "Arial"

mpl.rcParams["axes.titlesize"] = 12

mpl.rcParams["axes.labelsize"] = 11

mpl.rcParams["xtick.labelsize"] = 10

mpl.rcParams["ytick.labelsize"] = 10





# ============================================================

# 2. Helper functions

# ============================================================



def load_beta_matrix(path: Path) -> pd.DataFrame:

    if not path.exists():

        raise FileNotFoundError(

            f"Cannot find:\n{path}\n\n"

            "Please edit BETA_DIR at the top of this script."

        )



    df = pd.read_csv(path, index_col=0)



    if df.empty:

        raise ValueError(f"{path.name} is empty.")



    numeric = df.apply(pd.to_numeric, errors="coerce")

    if numeric.isna().any().any():

        bad = np.argwhere(numeric.isna().to_numpy())

        i, j = bad[0]

        raise ValueError(

            f"{path.name} contains a non-numeric/NaN value at "

            f"subject={df.index[i]}, ROI={df.columns[j]}."

        )



    return numeric





def compute_group_stats(beta_df: pd.DataFrame, label: str) -> pd.DataFrame:

    x = beta_df.to_numpy(dtype=float)

    n = x.shape[0]



    t_vals, p_vals = stats.ttest_1samp(

        x,

        popmean=0.0,

        axis=0,

        nan_policy="raise",

        alternative="two-sided",

    )



    reject, q_vals, _, _ = multipletests(

        p_vals,

        alpha=FDR_ALPHA,

        method="fdr_bh",

    )



    means = np.mean(x, axis=0)

    sds = np.std(x, axis=0, ddof=1)

    ses = sds / np.sqrt(n)



    tcrit = stats.t.ppf(0.975, df=n - 1)

    ci_low = means - tcrit * ses

    ci_high = means + tcrit * ses



    with np.errstate(divide="ignore", invalid="ignore"):

        dz = means / sds



    out = pd.DataFrame({

        "dimension": label,

        "roi": beta_df.columns,

        "n": n,

        "beta_mean": means,

        "beta_sd": sds,

        "t": t_vals,

        "p_uncorrected": p_vals,

        "q_fdr_bh": q_vals,

        "significant_fdr_q01": reject,

        "cohen_dz": dz,

        "ci95_low": ci_low,

        "ci95_high": ci_high,

    })



    return out





def normalize_label(x: str) -> str:

    s = str(x).lower()

    s = s.replace("schaefer", "")

    s = s.replace("roi", "")

    s = re.sub(r"[^a-z0-9]", "", s)

    return s





def decode_labels(labels):

    decoded = []

    for x in labels:

        if isinstance(x, bytes):

            decoded.append(x.decode("utf-8"))

        else:

            decoded.append(str(x))

    return decoded





def verify_schaefer_order(beta_columns, atlas_labels):

    if len(beta_columns) < N_SCHAEFER:

        raise ValueError(

            f"Only {len(beta_columns)} ROI columns were found; "

            f"at least {N_SCHAEFER} are required."

        )



    first200 = list(beta_columns[:N_SCHAEFER])



    if len(atlas_labels) != N_SCHAEFER:

        raise ValueError(

            f"Schaefer atlas returned {len(atlas_labels)} labels, "

            f"expected {N_SCHAEFER} parcel labels after removing background."

        )



    match = []

    for user_name, atlas_name in zip(first200, atlas_labels):

        u = normalize_label(user_name)

        a = normalize_label(atlas_name)

        ok = (u == a) or (a in u) or (u in a)

        match.append(ok)



    match_rate = np.mean(match)

    print(f"Schaefer label-order match rate: {match_rate:.3f}")



    if match_rate < 0.80:

        examples = []

        for i, ok in enumerate(match):

            if not ok:

                examples.append(

                    f"#{i+1}: beta='{first200[i]}' | atlas='{atlas_labels[i]}'"

                )

            if len(examples) >= 5:

                break



        raise ValueError(

            "The first 200 beta columns do not appear to match the "

            "standard Schaefer-200 atlas order.\n"

            "Do not continue with an incorrectly mapped brain figure.\n"

            "Examples:\n  " + "\n  ".join(examples)

        )





def schaefer_network(label: str) -> str:

    s = str(label)



    if "_Vis_" in s:

        return "Visual"

    if "_SomMot_" in s:

        return "Somatomotor"

    if "_DorsAttn_" in s:

        return "Dorsal attention"

    if "_SalVentAttn_" in s:

        return "Salience / ventral attention"

    if "_Limbic_" in s:

        return "Limbic"

    if "_Cont_" in s:

        return "Control"

    if "_Default_" in s:

        return "Default"



    raise ValueError(f"Cannot parse seven-network label from: {label}")





def parcel_values_to_nifti(parcel_values, atlas_img):

    atlas_data = atlas_img.get_fdata().astype(np.int32)



    if len(parcel_values) != N_SCHAEFER:

        raise ValueError(

            f"Expected {N_SCHAEFER} parcel values, got {len(parcel_values)}."

        )



    out = np.zeros(atlas_data.shape, dtype=np.float32)



    for parcel_index, value in enumerate(parcel_values, start=1):

        out[atlas_data == parcel_index] = float(value)



    return image.new_img_like(atlas_img, out)





def compute_network_alignment(

    cortical_t,

    cortical_t_fdr,

    atlas_labels,

    dimension_name,

):

    networks = [

        "Visual",

        "Somatomotor",

        "Dorsal attention",

        "Salience / ventral attention",

        "Limbic",

        "Control",

        "Default",

    ]



    memberships = np.array(

        [schaefer_network(label) for label in atlas_labels],

        dtype=object,

    )



    rows = []



    for network in networks:

        binary = (memberships == network).astype(int)



        r_unthresholded = stats.pointbiserialr(binary, cortical_t).statistic

        r_fdr = stats.pointbiserialr(binary, cortical_t_fdr).statistic



        rows.append({

            "dimension": dimension_name,

            "network": network,

            "n_parcels_in_network": int(binary.sum()),

            "r_unthresholded_tmap": float(r_unthresholded),

            "r_fdr_q01_zeroed_tmap": float(r_fdr),

        })



    return pd.DataFrame(rows)





def get_surface_textures(stat_img):

    """

    Project the Schaefer-volume t-map to a original fsaverage5 surface.

    """

    fsaverage = datasets.fetch_surf_fsaverage(mesh="fsaverage5")



    left_texture = surface.vol_to_surf(

        stat_img,

        fsaverage.pial_left,

        inner_mesh=fsaverage.white_left,

    )

    right_texture = surface.vol_to_surf(

        stat_img,

        fsaverage.pial_right,

        inner_mesh=fsaverage.white_right,

    )



    return fsaverage, left_texture, right_texture







def enhance_sulc_contrast(sulc_path):

    """

    Increase sulcal/gyral background contrast for visualization only.



    This does NOT alter statistical values. It only rescales the fsaverage

    sulcal map used as the gray anatomical background.

    """

    sulc = surface.load_surf_data(sulc_path).astype(float)



    finite = np.isfinite(sulc)

    if not np.any(finite):

        return sulc



    vals = sulc[finite]

    lo, hi = np.percentile(vals, [5, 95])



    if hi <= lo:

        return sulc



    # Robustly stretch to [-1, 1], then clip.

    stretched = (sulc - lo) / (hi - lo)

    stretched = stretched * 2.0 - 1.0

    stretched = np.clip(stretched, -1.0, 1.0)



    return stretched





def draw_brain_views_2x2(fig, gs_cell, goal_img, resp_img):

    """

    Panel A:

        2 x 2 conceptual brain-map layout



        top-left     Goal conduciveness, lateral view

        top-right    Agency attribution, lateral view

        bottom-left  Goal conduciveness, medial view

        bottom-right Agency attribution, medial view



    Each conceptual brain map contains BOTH hemispheres side by side.



    Important:

    We use plot_surf_stat_map here rather than plot_img_on_surf.

    plot_img_on_surf does not accept an externally supplied matplotlib

    figure/axes in the user's Nilearn version, which caused the previous

    ValueError.

    """



    # Use the same original fsaverage5 surface for both dimensions.

    fsavg = datasets.fetch_surf_fsaverage(mesh="fsaverage5")



    # Stronger anatomical background contrast (visualization only).

    sulc_left_bg = enhance_sulc_contrast(fsavg.sulc_left)

    sulc_right_bg = enhance_sulc_contrast(fsavg.sulc_right)



    # Project the ROI t-maps from MNI volume to fsaverage5 surfaces.

    goal_lh = surface.vol_to_surf(

        goal_img,

        fsavg.pial_left,

        inner_mesh=fsavg.white_left,

    )

    goal_rh = surface.vol_to_surf(

        goal_img,

        fsavg.pial_right,

        inner_mesh=fsavg.white_right,

    )



    resp_lh = surface.vol_to_surf(

        resp_img,

        fsavg.pial_left,

        inner_mesh=fsavg.white_left,

    )

    resp_rh = surface.vol_to_surf(

        resp_img,

        fsavg.pial_right,

        inner_mesh=fsavg.white_right,

    )



    # One common symmetric red-blue scale for Goal and Responsibility.

    all_vals = np.concatenate([

        goal_lh[np.isfinite(goal_lh)],

        goal_rh[np.isfinite(goal_rh)],

        resp_lh[np.isfinite(resp_lh)],

        resp_rh[np.isfinite(resp_rh)],

    ])

    nonzero = np.abs(all_vals[all_vals != 0])

    vmax = float(np.max(nonzero)) if nonzero.size else 1.0



    # 2 x 2 main layout:

    # left column = Agency attribution, right column = Goal conduciveness

    # top = lateral, bottom = medial

    main = gs_cell.subgridspec(

        2, 2,

        wspace=0.05,

        hspace=0.02,

    )



    cell_specs = [
        (0, 0, "Goal conduciveness", "lateral", goal_lh, goal_rh),
        (0, 1, "Agency attribution", "lateral", resp_lh, resp_rh),
        (1, 0, "Goal conduciveness", "medial", goal_lh, goal_rh),
        (1, 1, "Agency attribution", "medial", resp_lh, resp_rh),
    ]



    for row, col, dimension, view, tex_lh, tex_rh in cell_specs:



        # Within each conceptual panel, draw the two hemispheres side by side.

        hemi_grid = main[row, col].subgridspec(

            1, 2,

            wspace=-0.05,

        )



        ax_lh = fig.add_subplot(

            hemi_grid[0, 0],

            projection="3d",

        )

        ax_rh = fig.add_subplot(

            hemi_grid[0, 1],

            projection="3d",

        )



        plotting.plot_surf_stat_map(

            surf_mesh=fsavg.infl_left,

            stat_map=tex_lh,

            bg_map=sulc_left_bg,

            hemi="left",

            view=view,

            cmap="RdBu_r",

            colorbar=False,

            threshold=1e-12,

            symmetric_cbar=True,

            vmax=vmax,

            bg_on_data=True,

            axes=ax_lh,

            figure=fig,

        )



        plotting.plot_surf_stat_map(

            surf_mesh=fsavg.infl_right,

            stat_map=tex_rh,

            bg_map=sulc_right_bg,

            hemi="right",

            view=view,

            cmap="RdBu_r",

            colorbar=False,

            threshold=1e-12,

            symmetric_cbar=True,

            vmax=vmax,

            bg_on_data=True,

            axes=ax_rh,

            figure=fig,

        )



        # Clean 3D axes.

        ax_lh.set_axis_off()

        ax_rh.set_axis_off()



        # Dimension titles are centered over both hemispheres in each conceptual panel.
        if row == 0:
            left_box = ax_lh.get_position()
            right_box = ax_rh.get_position()
            x_center = (left_box.x0 + right_box.x1) / 2
            fig.text(
                x_center,
                max(left_box.y1, right_box.y1) + 0.004,
                dimension,
                ha="center",
                va="bottom",
                fontsize=10.5,
                fontweight="bold",
            )

        # Row labels only once, at the far left.

        if col == 0:

            ax_lh.text2D(

                -0.08,

                0.50,

                "Lateral view" if row == 0 else "Medial view",

                transform=ax_lh.transAxes,

                rotation=90,

                va="center",

                ha="center",

                fontsize=10.5,

            )



    # Shared colorbar for Panel A.

    # Coordinates are fixed relative to the final combined figure.

    cax = fig.add_axes([0.915, 0.585, 0.012, 0.215])

    norm = mpl.colors.Normalize(vmin=-vmax, vmax=vmax)

    cb = mpl.colorbar.ColorbarBase(

        cax,

        cmap=plt.get_cmap("RdBu_r"),

        norm=norm,

        orientation="vertical",

    )

    cb.set_label("t value", fontsize=10.5)

    cb.ax.tick_params(labelsize=9)





def plot_network_alignment_on_axis(ax, network_df: pd.DataFrame):

    if NETWORK_FIGURE_MODE == "fdr01":

        value_col = "r_fdr_q01_zeroed_tmap"


    elif NETWORK_FIGURE_MODE == "unthresholded":

        value_col = "r_unthresholded_tmap"


    else:

        raise ValueError(

            'NETWORK_FIGURE_MODE must be "fdr01" or "unthresholded".'

        )



    network_order = [

        "Visual",

        "Somatomotor",

        "Dorsal attention",

        "Salience / ventral attention",

        "Limbic",

        "Control",

        "Default",

    ]



    goal = (

        network_df[network_df["dimension"] == "Goal conduciveness"]

        .set_index("network")

        .loc[network_order, value_col]

        .to_numpy()

    )

    resp = (

        network_df[network_df["dimension"] == "Agency attribution"]

        .set_index("network")

        .loc[network_order, value_col]

        .to_numpy()

    )



    x = np.arange(len(network_order))

    width = 0.36



    # approximate the earlier behavior-figure palette:

    # green for Goal, purple for Responsibility

    goal_color = "#6DAA6F"

    resp_color = "#8E74B8"



    ax.bar(

        x - width / 2,

        goal,

        width,

        label="Goal conduciveness",

        color=goal_color,

    )

    ax.bar(

        x + width / 2,

        resp,

        width,

        label="Agency attribution",

        color=resp_color,

    )



    ax.axhline(0, linewidth=0.8, color="black")

    ax.set_ylabel("Point-biserial r")

    ax.set_xlabel("Canonical functional network")




    ax.set_xticks(x)

    ax.set_xticklabels(

        [

            "Visual",

            "Somatomotor",

            "Dorsal\nattention",

            "Salience /\nventral attention",

            "Limbic",

            "Control",

            "Default",

        ]

    )



    ax.legend(

        frameon=False,

        loc="upper right",

        ncol=2,

    )

    ax.spines["top"].set_visible(False)

    ax.spines["right"].set_visible(False)





def make_combined_figure(goal_img, resp_img, network_df):

    """

    One combined A+B figure with requested layout:

    - A on top

    - B on bottom

    """

    fig = plt.figure(figsize=(12.8, 14.2))

    outer = GridSpec(

        2,

        1,

        figure=fig,

        height_ratios=[2.8, 1.35],

        hspace=0.18,

    )



    # Panel A title

    axA_title = fig.add_subplot(outer[0])

    axA_title.axis("off")

    axA_title.text(
        0.00, 1.03,
        "A. Group-level t-statistic maps",
        fontsize=15, fontweight="bold",
        transform=axA_title.transAxes,
        ha="left", va="bottom",
    )



    # Brain views are drawn inside the same top panel cell

    draw_brain_views_2x2(fig, outer[0], goal_img, resp_img)



    # Panel B

    axB = fig.add_subplot(outer[1])

    plot_network_alignment_on_axis(axB, network_df)



    axB.text(
        0.00, 1.10,
        "B. Spatial correspondence with canonical functional networks",
        fontsize=15, fontweight="bold",
        transform=axB.transAxes,
        ha="left", va="bottom",
    )



    fig.savefig(OUT_DIR / "Fig_AB_combined.svg", bbox_inches="tight")

    fig.savefig(OUT_DIR / "Fig_AB_combined.pdf", bbox_inches="tight")

    fig.savefig(OUT_DIR / "Fig_AB_combined.png", dpi=600, bbox_inches="tight")

    plt.close(fig)





# ============================================================

# 3. Load beta matrices

# ============================================================



print("=" * 72)

print("Loading first-level beta matrices")

print("=" * 72)



goal_beta = load_beta_matrix(GOAL_BETA_FILE)

resp_beta = load_beta_matrix(RESP_BETA_FILE)



if list(goal_beta.index) != list(resp_beta.index):

    raise ValueError("Goal and Responsibility files have different subject order.")



if list(goal_beta.columns) != list(resp_beta.columns):

    raise ValueError("Goal and Responsibility files have different ROI order.")



if goal_beta.shape[1] != N_EXPECTED_ROIS:

    warnings.warn(

        f"Expected {N_EXPECTED_ROIS} ROI columns, but found "

        f"{goal_beta.shape[1]}. The script will continue, but check your data."

    )



print(f"Goal beta matrix: {goal_beta.shape}")

print(f"Responsibility beta matrix: {resp_beta.shape}")





# ============================================================

# 4. Group-level full-sample statistics

# ============================================================



print("\n" + "=" * 72)

print("A. Full-sample group-level effect maps")

print("=" * 72)



goal_stats = compute_group_stats(goal_beta, label="Goal conduciveness")

resp_stats = compute_group_stats(resp_beta, label="Agency attribution")



goal_stats.to_csv(OUT_DIR / "group_stats_goal_all221.csv", index=False)

resp_stats.to_csv(OUT_DIR / "group_stats_responsibility_all221.csv", index=False)



print(

    "Goal significant ROIs at FDR q < .01:",

    int(goal_stats["significant_fdr_q01"].sum()),

)

print(

    "Responsibility significant ROIs at FDR q < .01:",

    int(resp_stats["significant_fdr_q01"].sum()),

)





# ============================================================

# 5. Fetch standard Schaefer-200 7-network atlas

# ============================================================



print("\nFetching Schaefer-200 7-network atlas...")



schaefer = datasets.fetch_atlas_schaefer_2018(

    n_rois=N_SCHAEFER,

    yeo_networks=7,

    resolution_mm=2,

)



atlas_img = nib.load(schaefer.maps)

atlas_labels_all = decode_labels(schaefer.labels)



if len(atlas_labels_all) == N_SCHAEFER + 1:

    first_label = atlas_labels_all[0].strip().lower()

    if first_label in {"background", "bg"}:

        print(

            f"Schaefer atlas returned {len(atlas_labels_all)} labels "

            f"including background; removing the background label."

        )

        atlas_labels = atlas_labels_all[1:]

    else:

        raise ValueError(

            f"Schaefer atlas returned {len(atlas_labels_all)} labels, "

            "but the first label is not recognized as background: "

            f"{atlas_labels_all[0]!r}"

        )

elif len(atlas_labels_all) == N_SCHAEFER:

    atlas_labels = atlas_labels_all

else:

    raise ValueError(

        f"Schaefer atlas returned {len(atlas_labels_all)} labels; "

        f"expected {N_SCHAEFER} parcel labels or "

        f"{N_SCHAEFER + 1} labels including background."

    )



verify_schaefer_order(

    beta_columns=goal_beta.columns,

    atlas_labels=atlas_labels,

)





# ============================================================

# 6. Build q < .01 cortical t-maps and save NIfTI

# ============================================================



goal_t_200 = goal_stats["t"].to_numpy()[:N_SCHAEFER]

resp_t_200 = resp_stats["t"].to_numpy()[:N_SCHAEFER]



goal_sig_200 = goal_stats["significant_fdr_q01"].to_numpy(dtype=bool)[:N_SCHAEFER]

resp_sig_200 = resp_stats["significant_fdr_q01"].to_numpy(dtype=bool)[:N_SCHAEFER]



goal_t_fdr = np.where(goal_sig_200, goal_t_200, 0.0)

resp_t_fdr = np.where(resp_sig_200, resp_t_200, 0.0)



goal_stat_img = parcel_values_to_nifti(goal_t_fdr, atlas_img)

resp_stat_img = parcel_values_to_nifti(resp_t_fdr, atlas_img)



goal_nii = OUT_DIR / "goal_t_FDRq01_schaefer200.nii.gz"

resp_nii = OUT_DIR / "responsibility_t_FDRq01_schaefer200.nii.gz"



goal_stat_img.to_filename(goal_nii)

resp_stat_img.to_filename(resp_nii)



print(f"Saved: {goal_nii}")

print(f"Saved: {resp_nii}")





# ============================================================

# 7. Seven-network alignment

# ============================================================



print("\n" + "=" * 72)

print("B. Seven-network alignment")

print("=" * 72)



goal_network = compute_network_alignment(

    cortical_t=goal_t_200,

    cortical_t_fdr=goal_t_fdr,

    atlas_labels=atlas_labels,

    dimension_name="Goal conduciveness",

)



resp_network = compute_network_alignment(

    cortical_t=resp_t_200,

    cortical_t_fdr=resp_t_fdr,

    atlas_labels=atlas_labels,

    dimension_name="Agency attribution",

)



network_df = pd.concat([goal_network, resp_network], ignore_index=True)

network_df.to_csv(OUT_DIR / "network_alignment_goal_responsibility.csv", index=False)



print("\nNetwork alignment:")

print(

    network_df[

        [

            "dimension",

            "network",

            "r_fdr_q01_zeroed_tmap",

            "r_unthresholded_tmap",

        ]

    ].to_string(index=False)

)





# ============================================================

# 8. Combined A+B figure

# ============================================================



print("\nCreating combined A+B figure...")

make_combined_figure(goal_stat_img, resp_stat_img, network_df)



print("\n" + "=" * 72)

print("Done")

print("=" * 72)

print(f"Output directory:\n{OUT_DIR}")

print("\nMain figure:")

print("  Fig_AB_combined.svg / .pdf / .png")
