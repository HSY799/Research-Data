# -*- coding: utf-8 -*-
"""
glm_layer2_direction_controlled.py
==================================
Within-dimension directional first-level ROI GLMs.

Goal-direction model
--------------------
BOLD ~ goal_facil + goal_block + responsibility(signed)
       + 24 motion + DCT + intercept

Responsibility-direction model
------------------------------
BOLD ~ self_resp + other_resp + goal(signed)
       + 24 motion + DCT + intercept

This keeps the "other appraisal dimension" in the model as a control regressor,
matching the logic of the formal Layer-1 joint model.

Outputs
-------
glm_layer2_direction_controlled/
    design_goal_direction.csv
    design_responsibility_direction.csv
    beta_goal_facil.csv
    beta_goal_block.csv
    beta_self_resp.csv
    beta_other_resp.csv
"""

import os
import glob
import numpy as np
import pandas as pd

from nilearn.glm.first_level import make_first_level_design_matrix, run_glm


# ============================================================
# 1. Configuration
# ============================================================

BOLD_DIR = "221fmri"
BEHAVIOR_FILE = "xw/w3fmri.csv"
CONFOUNDS_DIR = r"D:\confounds_selected"
OUTPUT_DIR = "glm_layer2_direction_controlled"

TARGET_ROWS = 3526
TR = 1.0

HRF_MODEL = "glover"
DRIFT_MODEL = "cosine"
HIGH_PASS = 1 / 128
NOISE_MODEL = "ols"

MOTION_COLS = [
    "trans_x", "trans_x_derivative1", "trans_x_power2", "trans_x_derivative1_power2",
    "trans_y", "trans_y_derivative1", "trans_y_power2", "trans_y_derivative1_power2",
    "trans_z", "trans_z_derivative1", "trans_z_power2", "trans_z_derivative1_power2",
    "rot_x",   "rot_x_derivative1",   "rot_x_power2",   "rot_x_derivative1_power2",
    "rot_y",   "rot_y_derivative1",   "rot_y_power2",   "rot_y_derivative1_power2",
    "rot_z",   "rot_z_derivative1",   "rot_z_power2",   "rot_z_derivative1_power2",
]

os.makedirs(OUTPUT_DIR, exist_ok=True)


# ============================================================
# 2. Behavior: construct split non-negative regressors
# ============================================================

beh = pd.read_csv(BEHAVIOR_FILE)

required_cols = ["goal", "zrgy"]
missing = [c for c in required_cols if c not in beh.columns]
if missing:
    raise ValueError(f"Behavior file missing columns: {missing}")

if len(beh) != TARGET_ROWS:
    raise ValueError(
        f"Behavior rows={len(beh)}, expected {TARGET_ROWS}."
    )

goal = pd.to_numeric(beh["goal"], errors="coerce").to_numpy(float)
responsibility = pd.to_numeric(beh["zrgy"], errors="coerce").to_numpy(float)

if not np.isfinite(goal).all():
    raise ValueError("goal contains NaN/Inf.")
if not np.isfinite(responsibility).all():
    raise ValueError("zrgy/responsibility contains NaN/Inf.")

goal_facil = np.where(goal > 0, goal, 0.0)
goal_block = np.where(goal < 0, -goal, 0.0)

self_resp = np.where(responsibility > 0, responsibility, 0.0)
other_resp = np.where(responsibility < 0, -responsibility, 0.0)

print("=" * 72)
print("Behavior regressors")
print("=" * 72)
print(f"Goal range: {goal.min():.6f} ~ {goal.max():.6f}")
print(f"Responsibility range: {responsibility.min():.6f} ~ {responsibility.max():.6f}")
print(f"Raw Goal-Responsibility r = {np.corrcoef(goal, responsibility)[0,1]:.6f}")
print(f"goal_facil nonzero = {(goal_facil > 0).mean()*100:.2f}%")
print(f"goal_block nonzero = {(goal_block > 0).mean()*100:.2f}%")
print(f"self_resp nonzero  = {(self_resp > 0).mean()*100:.2f}%")
print(f"other_resp nonzero = {(other_resp > 0).mean()*100:.2f}%")


# ============================================================
# 3. Helpers for design matrices
# ============================================================

frame_times = np.arange(TARGET_ROWS, dtype=float) * TR


def add_modulated_events(events_list, name, values, positive_only=False):
    """
    Add one 1-s event per TR.

    For split non-negative regressors, zero-amplitude events are omitted.
    For signed control regressors, all nonzero amplitudes are included.
    """
    for t_idx, amp in enumerate(values):
        amp = float(amp)

        if positive_only:
            if amp <= 0:
                continue
        else:
            if amp == 0:
                continue

        events_list.append({
            "onset": float(t_idx) * TR,
            "duration": TR,
            "trial_type": name,
            "modulation": amp,
        })


# Goal-direction model:
# goal_facil + goal_block + signed responsibility
events_goal = []
add_modulated_events(events_goal, "goal_facil", goal_facil, positive_only=True)
add_modulated_events(events_goal, "goal_block", goal_block, positive_only=True)
add_modulated_events(events_goal, "responsibility", responsibility, positive_only=False)

events_goal_df = pd.DataFrame(events_goal)

dm_goal_base = make_first_level_design_matrix(
    frame_times=frame_times,
    events=events_goal_df,
    hrf_model=HRF_MODEL,
    drift_model=DRIFT_MODEL,
    high_pass=HIGH_PASS,
    oversampling=50,
)

goal_required = ["goal_facil", "goal_block", "responsibility"]
for col in goal_required:
    if col not in dm_goal_base.columns:
        raise ValueError(
            f"Goal-direction design missing '{col}'. "
            f"Columns: {list(dm_goal_base.columns)}"
        )

dm_goal_base.to_csv(
    os.path.join(OUTPUT_DIR, "design_goal_direction.csv"),
    index=False,
)


# Responsibility-direction model:
# self_resp + other_resp + signed goal
events_resp = []
add_modulated_events(events_resp, "self_resp", self_resp, positive_only=True)
add_modulated_events(events_resp, "other_resp", other_resp, positive_only=True)
add_modulated_events(events_resp, "goal", goal, positive_only=False)

events_resp_df = pd.DataFrame(events_resp)

dm_resp_base = make_first_level_design_matrix(
    frame_times=frame_times,
    events=events_resp_df,
    hrf_model=HRF_MODEL,
    drift_model=DRIFT_MODEL,
    high_pass=HIGH_PASS,
    oversampling=50,
)

resp_required = ["self_resp", "other_resp", "goal"]
for col in resp_required:
    if col not in dm_resp_base.columns:
        raise ValueError(
            f"Responsibility-direction design missing '{col}'. "
            f"Columns: {list(dm_resp_base.columns)}"
        )

dm_resp_base.to_csv(
    os.path.join(OUTPUT_DIR, "design_responsibility_direction.csv"),
    index=False,
)

print("\nDesign matrices created:")
print(f"  Goal-direction: {dm_goal_base.shape}")
print(f"  Responsibility-direction: {dm_resp_base.shape}")


# ============================================================
# 4. Find and validate subject files
# ============================================================

bold_files = sorted(
    glob.glob(os.path.join(BOLD_DIR, "*_Combined_Schaefer_HO*.csv"))
)
conf_files = sorted(
    glob.glob(os.path.join(CONFOUNDS_DIR, "*.tsv"))
)

if not bold_files:
    raise FileNotFoundError(f"No BOLD CSVs found in {BOLD_DIR}")
if not conf_files:
    raise FileNotFoundError(f"No confound TSVs found in {CONFOUNDS_DIR}")

confound_map = {}
for cf in conf_files:
    sub_id = os.path.basename(cf).split("_")[0]
    confound_map.setdefault(sub_id, []).append(cf)

reference_roi_names = None

for bold_path in bold_files:
    sub_id = os.path.basename(bold_path).split("_")[0]

    bold_raw = pd.read_csv(bold_path)
    if len(bold_raw) != TARGET_ROWS:
        raise ValueError(
            f"{sub_id}: BOLD rows={len(bold_raw)}, expected {TARGET_ROWS}"
        )

    roi_df = bold_raw.iloc[:, 1:]
    roi_names = list(roi_df.columns)

    if reference_roi_names is None:
        reference_roi_names = roi_names
    elif roi_names != reference_roi_names:
        raise ValueError(f"{sub_id}: ROI columns/order differ.")

    if not np.isfinite(roi_df.to_numpy(float)).all():
        raise ValueError(f"{sub_id}: BOLD contains NaN/Inf.")

    matches = confound_map.get(sub_id, [])
    if len(matches) != 1:
        raise ValueError(
            f"{sub_id}: expected exactly one confounds file, found {len(matches)}."
        )

    conf_df = pd.read_csv(matches[0], sep="\t", usecols=MOTION_COLS)
    if len(conf_df) != TARGET_ROWS:
        raise ValueError(
            f"{sub_id}: confound rows={len(conf_df)}, expected {TARGET_ROWS}"
        )

    if not np.isfinite(conf_df[MOTION_COLS].to_numpy(float)).all():
        raise ValueError(f"{sub_id}: motion confounds contain NaN/Inf.")

print(
    f"\nValidation passed: participants={len(bold_files)}, "
    f"ROIs={len(reference_roi_names)}, timepoints={TARGET_ROWS}"
)


# ============================================================
# 5. Fit two controlled first-level OLS GLMs per subject
# ============================================================

all_goal_facil = []
all_goal_block = []
all_self_resp = []
all_other_resp = []
subject_ids = []

for fi, bold_path in enumerate(bold_files, start=1):
    sub_id = os.path.basename(bold_path).split("_")[0]

    # BOLD: 3526 x 221
    bold_raw = pd.read_csv(bold_path)
    Y = bold_raw.iloc[:, 1:].to_numpy(float)

    # 24 motion
    conf_path = confound_map[sub_id][0]
    motion_df = (
        pd.read_csv(conf_path, sep="\t", usecols=MOTION_COLS)
        [MOTION_COLS]
        .astype(float)
        .reset_index(drop=True)
    )

    # ---------------- Goal-direction GLM ----------------
    dm_goal_full = pd.concat(
        [dm_goal_base.reset_index(drop=True), motion_df],
        axis=1,
    )
    Xg = dm_goal_full.to_numpy(float)

    rank_g = np.linalg.matrix_rank(Xg)
    if rank_g < Xg.shape[1]:
        raise ValueError(
            f"{sub_id}: Goal-direction design not full rank: "
            f"rank={rank_g}, columns={Xg.shape[1]}"
        )

    labels_g, results_g = run_glm(
        Y,
        Xg,
        noise_model=NOISE_MODEL,
    )

    col_g = list(dm_goal_full.columns)
    idx_facil = col_g.index("goal_facil")
    idx_block = col_g.index("goal_block")

    n_rois = Y.shape[1]
    beta_facil_sub = np.full(n_rois, np.nan)
    beta_block_sub = np.full(n_rois, np.nan)

    for roi_idx in range(n_rois):
        label = labels_g[roi_idx]
        result = results_g[label]
        roi_positions = np.where(labels_g == label)[0]
        pos_in_group = np.where(roi_positions == roi_idx)[0][0]
        beta_all = result.theta[:, pos_in_group]

        beta_facil_sub[roi_idx] = beta_all[idx_facil]
        beta_block_sub[roi_idx] = beta_all[idx_block]

    # ------------- Responsibility-direction GLM -------------
    dm_resp_full = pd.concat(
        [dm_resp_base.reset_index(drop=True), motion_df],
        axis=1,
    )
    Xr = dm_resp_full.to_numpy(float)

    rank_r = np.linalg.matrix_rank(Xr)
    if rank_r < Xr.shape[1]:
        raise ValueError(
            f"{sub_id}: Responsibility-direction design not full rank: "
            f"rank={rank_r}, columns={Xr.shape[1]}"
        )

    labels_r, results_r = run_glm(
        Y,
        Xr,
        noise_model=NOISE_MODEL,
    )

    col_r = list(dm_resp_full.columns)
    idx_self = col_r.index("self_resp")
    idx_other = col_r.index("other_resp")

    beta_self_sub = np.full(n_rois, np.nan)
    beta_other_sub = np.full(n_rois, np.nan)

    for roi_idx in range(n_rois):
        label = labels_r[roi_idx]
        result = results_r[label]
        roi_positions = np.where(labels_r == label)[0]
        pos_in_group = np.where(roi_positions == roi_idx)[0][0]
        beta_all = result.theta[:, pos_in_group]

        beta_self_sub[roi_idx] = beta_all[idx_self]
        beta_other_sub[roi_idx] = beta_all[idx_other]

    for arr, name in [
        (beta_facil_sub, "goal_facil"),
        (beta_block_sub, "goal_block"),
        (beta_self_sub, "self_resp"),
        (beta_other_sub, "other_resp"),
    ]:
        if not np.isfinite(arr).all():
            raise ValueError(f"{sub_id}: {name} beta contains NaN/Inf.")

    all_goal_facil.append(beta_facil_sub)
    all_goal_block.append(beta_block_sub)
    all_self_resp.append(beta_self_sub)
    all_other_resp.append(beta_other_sub)
    subject_ids.append(sub_id)

    print(
        f"[{fi:02d}/{len(bold_files):02d}] {sub_id} | "
        f"Goal X={Xg.shape}, rank={rank_g} | "
        f"Resp X={Xr.shape}, rank={rank_r}"
    )


# ============================================================
# 6. Save 40 x 221 beta matrices
# ============================================================

roi_names = reference_roi_names

outputs = {
    "beta_goal_facil.csv": np.vstack(all_goal_facil),
    "beta_goal_block.csv": np.vstack(all_goal_block),
    "beta_self_resp.csv": np.vstack(all_self_resp),
    "beta_other_resp.csv": np.vstack(all_other_resp),
}

for fname, matrix in outputs.items():
    df = pd.DataFrame(
        matrix,
        index=subject_ids,
        columns=roi_names,
    )
    out_path = os.path.join(OUTPUT_DIR, fname)
    df.to_csv(out_path)
    print(f"Saved {fname}: {df.shape}")

print("\nDone.")
