# -*- coding: utf-8 -*-
r"""
glm_layer1_goal_resp_formal.py
================================
正式 Layer-1 ROI fMRI GLM：Goal + Responsibility 联合模型

目的
----
生成：
    beta_layer1_goal_resp_goal.csv
    beta_layer1_goal_resp_responsibility.csv

相对于原 glm_analysis.py 的修改：
1. 四个拆分回归量改为两个有符号连续回归量：goal、responsibility(zrgy)
2. HRF 从 "glover + derivative" 改为 canonical Glover："glover"
3. 噪声模型从 AR(1) 改为 OLS：noise_model="ols"
4. 保留原代码的 Nilearn 标准设计矩阵流程：
       make_first_level_design_matrix(..., oversampling=50)
   不使用手写 np.convolve
5. 保留原代码的 24 个 fMRIPrep 头动参数，直接读取，不自行重算
6. 保留 cosine DCT 高通滤波，截止频率 1/128 Hz
7. 不加入 CSF
8. 不加入 spike regressors
9. confounds 路径改为 D:\confounds_selected；文件中可包含29列，但本GLM只读取其中24个头动参数
10. 增强数据完整性检查：所有被试均检查 3526 行、24 个头动列、ROI 顺序和有限值

一级模型
--------
BOLD ~ Goal + Responsibility + 24 motion + DCT + intercept

说明
----
- Goal 和 Responsibility 均保留正负号，不拆分。
- Goal/Responsibility 同时进入同一个 GLM，因此每个 beta 表示控制另一评价维度后的独立效应。
- 本脚本只生成一级 beta 矩阵，不在这里做组水平 t 检验或镜像约束检验。
"""

import os
import glob
import numpy as np
import pandas as pd

from nilearn.glm.first_level import make_first_level_design_matrix, run_glm


# ============================================================
# 1. 配置
# ============================================================

BOLD_DIR = "221fmri"
BEHAVIOR_FILE = "xw/w3fmri.csv"
CONFOUNDS_DIR = r"D:\confounds_selected"
OUTPUT_DIR = "glm_layer1_goal_resp"

TARGET_ROWS = 3526
TR = 1.0

# canonical-only Glover HRF
HRF_MODEL = "glover"

# 与原代码相同
DRIFT_MODEL = "cosine"
HIGH_PASS = 1 / 128

# Miao-style 主模型规格：OLS
NOISE_MODEL = "ols"

# 直接读取你已经筛选并转移到 D:\confounds_selected 的 24 个 fMRIPrep 头动参数；不自行重算
MOTION_COLS = [
    "trans_x", "trans_x_derivative1", "trans_x_power2", "trans_x_derivative1_power2",
    "trans_y", "trans_y_derivative1", "trans_y_power2", "trans_y_derivative1_power2",
    "trans_z", "trans_z_derivative1", "trans_z_power2", "trans_z_derivative1_power2",
    "rot_x",   "rot_x_derivative1",   "rot_x_power2",   "rot_x_derivative1_power2",
    "rot_y",   "rot_y_derivative1",   "rot_y_power2",   "rot_y_derivative1_power2",
    "rot_z",   "rot_z_derivative1",   "rot_z_power2",   "rot_z_derivative1_power2",
]

REGRESSOR_NAMES = ["goal", "responsibility"]

os.makedirs(OUTPUT_DIR, exist_ok=True)


# ============================================================
# 2. 读取行为数据
# ============================================================

print("=" * 70)
print("1. 读取行为数据")
print("=" * 70)

beh = pd.read_csv(BEHAVIOR_FILE)

required_behavior_cols = ["goal", "zrgy"]
missing_behavior_cols = [c for c in required_behavior_cols if c not in beh.columns]
if missing_behavior_cols:
    raise ValueError(
        f"行为文件缺少必要列: {missing_behavior_cols}\n"
        f"当前列: {list(beh.columns)}"
    )

if len(beh) != TARGET_ROWS:
    raise ValueError(
        f"行为文件行数为 {len(beh)}，预期为 {TARGET_ROWS}。"
    )

goal = pd.to_numeric(beh["goal"], errors="coerce").to_numpy(dtype=float)
responsibility = pd.to_numeric(beh["zrgy"], errors="coerce").to_numpy(dtype=float)

if not np.isfinite(goal).all():
    raise ValueError("goal 序列包含 NaN 或 Inf。")
if not np.isfinite(responsibility).all():
    raise ValueError("zrgy/responsibility 序列包含 NaN 或 Inf。")

print(f"  行为数据: {len(beh)} 行")
print(f"  Goal范围: {goal.min():.6f} ~ {goal.max():.6f}")
print(
    f"  Responsibility范围: "
    f"{responsibility.min():.6f} ~ {responsibility.max():.6f}"
)
print(
    f"  原始 Goal–Responsibility Pearson r = "
    f"{np.corrcoef(goal, responsibility)[0, 1]:.6f}"
)


# ============================================================
# 3. 用 Nilearn 官方函数构建设计矩阵
# ============================================================

print("\n" + "=" * 70)
print("2. 构建设计矩阵")
print("=" * 70)

frame_times = np.arange(TARGET_ROWS, dtype=float) * TR

# 保留原代码的 events + modulation 方式。
# 与四拆分模型不同，这里 goal / responsibility 保留正负号，
# 因此不能再使用原来的 `if amp > 0`。
events_list = []

for t_idx in range(TARGET_ROWS):
    onset = float(t_idx) * TR

    events_list.append({
        "onset": onset,
        "duration": TR,
        "trial_type": "goal",
        "modulation": float(goal[t_idx]),
    })

    events_list.append({
        "onset": onset,
        "duration": TR,
        "trial_type": "responsibility",
        "modulation": float(responsibility[t_idx]),
    })

events_df = pd.DataFrame(events_list)

# canonical Glover + DCT 1/128 Hz；全部由 Nilearn 官方函数完成
dm_base = make_first_level_design_matrix(
    frame_times=frame_times,
    events=events_df,
    hrf_model=HRF_MODEL,
    drift_model=DRIFT_MODEL,
    high_pass=HIGH_PASS,
    oversampling=50,
)

for reg in REGRESSOR_NAMES:
    if reg not in dm_base.columns:
        raise ValueError(
            f"设计矩阵中没有找到任务回归量 '{reg}'。\n"
            f"实际列为: {list(dm_base.columns)}"
        )

print(f"  基础设计矩阵: {dm_base.shape}")
print(f"  HRF模型: {HRF_MODEL}")
print(f"  漂移模型: {DRIFT_MODEL}, high_pass={HIGH_PASS}")
print(f"  任务列: {[c for c in dm_base.columns if c in REGRESSOR_NAMES]}")
print(f"  DCT列数: {sum(str(c).startswith('drift_') for c in dm_base.columns)}")

# 保存基础设计矩阵，便于人工检查
DM_EXAMPLE_FILE = os.path.join(OUTPUT_DIR, "design_matrix_layer1_goal_resp.csv")
dm_base.to_csv(DM_EXAMPLE_FILE, index=False)
print(f"  设计矩阵已保存: {DM_EXAMPLE_FILE}")


# ============================================================
# 4. 查找并完整检查 BOLD / confounds 文件
# ============================================================

print("\n" + "=" * 70)
print("3. 检查所有被试文件")
print("=" * 70)

bold_files = sorted(
    glob.glob(os.path.join(BOLD_DIR, "*_Combined_Schaefer_HO*.csv"))
)
conf_files_all = sorted(
    glob.glob(os.path.join(CONFOUNDS_DIR, "*.tsv"))
)

if len(bold_files) == 0:
    raise FileNotFoundError(
        f"在 {BOLD_DIR} 中没有找到 *_Combined_Schaefer_HO*.csv"
    )

if len(conf_files_all) == 0:
    raise FileNotFoundError(
        f"在 {CONFOUNDS_DIR} 中没有找到 TSV confounds 文件"
    )

print(f"  BOLD文件数: {len(bold_files)}")
print(f"  Confounds目录: {CONFOUNDS_DIR}")
print(f"  Confounds文件数: {len(conf_files_all)}")

# 建立 subject -> confound file 映射；要求每个 subject 唯一匹配
confound_map = {}
for cf in conf_files_all:
    base = os.path.basename(cf)
    sub_id = base.split("_")[0]
    confound_map.setdefault(sub_id, []).append(cf)

# 第一个被试定义参考 ROI 顺序
reference_roi_names = None

for bold_path in bold_files:
    fname = os.path.basename(bold_path)
    sub_id = fname.split("_")[0]

    bold_raw = pd.read_csv(bold_path)
    if len(bold_raw) != TARGET_ROWS:
        raise ValueError(
            f"{sub_id}: BOLD 行数={len(bold_raw)}，预期={TARGET_ROWS}"
        )

    # 第一列为 Time_Seconds；后面是 ROI
    bold_df = bold_raw.iloc[:, 1:]
    roi_names_this = list(bold_df.columns)

    if reference_roi_names is None:
        reference_roi_names = roi_names_this
    elif roi_names_this != reference_roi_names:
        raise ValueError(
            f"{sub_id}: ROI 列名或顺序与第一个被试不一致。"
        )

    bold_values = bold_df.to_numpy(dtype=float)
    if not np.isfinite(bold_values).all():
        raise ValueError(f"{sub_id}: BOLD ROI 数据包含 NaN 或 Inf。")

    matches = confound_map.get(sub_id, [])
    if len(matches) == 0:
        raise FileNotFoundError(f"{sub_id}: 找不到对应 confounds 文件。")
    if len(matches) > 1:
        raise ValueError(
            f"{sub_id}: 找到多个 confounds 文件，无法唯一确定:\n"
            + "\n".join(matches)
        )

    # 你筛选后的文件有29列；本GLM只使用下面24个头动参数
    conf_df = pd.read_csv(matches[0], sep="\t", usecols=MOTION_COLS)
    if len(conf_df) != TARGET_ROWS:
        raise ValueError(
            f"{sub_id}: confounds 行数={len(conf_df)}，预期={TARGET_ROWS}"
        )

    missing_motion = [c for c in MOTION_COLS if c not in conf_df.columns]
    if missing_motion:
        raise ValueError(
            f"{sub_id}: 缺少以下头动参数: {missing_motion}"
        )

    motion_df = conf_df[MOTION_COLS].apply(pd.to_numeric, errors="coerce")
    if not np.isfinite(motion_df.to_numpy(dtype=float)).all():
        raise ValueError(
            f"{sub_id}: 24个头动参数中存在 NaN 或 Inf。"
        )

print(
    f"  全部被试检查通过；ROI数={len(reference_roi_names)}，"
    f"每名被试时间点={TARGET_ROWS}"
)


# ============================================================
# 5. 逐被试 OLS GLM
# ============================================================

print("\n" + "=" * 70)
print("4. 第一阶段：逐被试 GLM")
print("=" * 70)
print(f"  noise_model = {NOISE_MODEL}")
print("  nuisance = 24 motion + DCT")
print("  CSF = 不加入")
print("  spike regressors = 不加入")

all_goal_betas = []
all_resp_betas = []
subject_ids = []
roi_names = reference_roi_names

for fi, bold_path in enumerate(bold_files, start=1):

    fname = os.path.basename(bold_path)
    sub_id = fname.split("_")[0]

    # ---------- BOLD ----------
    bold_raw = pd.read_csv(bold_path)
    bold_df = bold_raw.iloc[:, 1:]
    Y = bold_df.to_numpy(dtype=float)  # 3526 × 221

    # ---------- 24 motion ----------
    conf_path = confound_map[sub_id][0]
    # 直接从 D:\confounds_selected 读取24个头动参数；不读取 csf/FD/global_signal/dvars/std_dvars
    conf_df = pd.read_csv(conf_path, sep="\t", usecols=MOTION_COLS)
    motion_df = conf_df[MOTION_COLS].astype(float).reset_index(drop=True)

    # ---------- 完整设计矩阵 ----------
    # dm_base 已包括 Goal、Responsibility、DCT、constant
    dm_full = pd.concat(
        [
            dm_base.reset_index(drop=True),
            motion_df,
        ],
        axis=1,
    )

    X = dm_full.to_numpy(dtype=float)

    if X.shape[0] != Y.shape[0]:
        raise ValueError(
            f"{sub_id}: X行数={X.shape[0]} 与 Y行数={Y.shape[0]} 不一致"
        )

    if not np.isfinite(X).all():
        raise ValueError(f"{sub_id}: 设计矩阵包含 NaN 或 Inf。")

    # 这里只做诊断，不修改设计矩阵
    matrix_rank = np.linalg.matrix_rank(X)
    if matrix_rank < X.shape[1]:
        raise ValueError(
            f"{sub_id}: 设计矩阵不满秩，"
            f"rank={matrix_rank}, columns={X.shape[1]}。"
        )

    # ---------- Nilearn 官方 OLS ----------
    labels, results = run_glm(
        Y,
        X,
        noise_model=NOISE_MODEL,
    )

    col_names = list(dm_full.columns)
    goal_idx = col_names.index("goal")
    resp_idx = col_names.index("responsibility")

    n_rois = Y.shape[1]
    goal_betas_sub = np.full(n_rois, np.nan)
    resp_betas_sub = np.full(n_rois, np.nan)

    # 沿用你原代码对 run_glm 输出 beta 的标准读取方式
    for roi_idx in range(n_rois):
        label = labels[roi_idx]
        result = results[label]

        roi_positions = np.where(labels == label)[0]
        pos_in_group = np.where(roi_positions == roi_idx)[0][0]

        beta_all = result.theta[:, pos_in_group]

        goal_betas_sub[roi_idx] = beta_all[goal_idx]
        resp_betas_sub[roi_idx] = beta_all[resp_idx]

    if not np.isfinite(goal_betas_sub).all():
        raise ValueError(f"{sub_id}: Goal beta 中存在 NaN 或 Inf。")
    if not np.isfinite(resp_betas_sub).all():
        raise ValueError(f"{sub_id}: Responsibility beta 中存在 NaN 或 Inf。")

    all_goal_betas.append(goal_betas_sub)
    all_resp_betas.append(resp_betas_sub)
    subject_ids.append(sub_id)

    print(
        f"  [{fi:02d}/{len(bold_files):02d}] {sub_id}  "
        f"Y={Y.shape}  X={X.shape}  rank={matrix_rank}"
    )


# ============================================================
# 6. 保存正式 40 × 221 beta 矩阵
# ============================================================

print("\n" + "=" * 70)
print("5. 保存一级 beta")
print("=" * 70)

goal_beta_df = pd.DataFrame(
    np.vstack(all_goal_betas),
    index=subject_ids,
    columns=roi_names,
)

resp_beta_df = pd.DataFrame(
    np.vstack(all_resp_betas),
    index=subject_ids,
    columns=roi_names,
)

goal_out = os.path.join(
    OUTPUT_DIR,
    "beta_layer1_goal_resp_goal.csv",
)

resp_out = os.path.join(
    OUTPUT_DIR,
    "beta_layer1_goal_resp_responsibility.csv",
)

goal_beta_df.to_csv(goal_out)
resp_beta_df.to_csv(resp_out)

print(f"  Goal beta: {goal_beta_df.shape}")
print(f"  Responsibility beta: {resp_beta_df.shape}")
print("\n已保存：")
print(f"  {goal_out}")
print(f"  {resp_out}")
print("\n完成。")
